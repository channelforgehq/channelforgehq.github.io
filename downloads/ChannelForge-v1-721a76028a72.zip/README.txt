ChannelForge — your AI-run YouTube studio
==========================================

One step to install:

  Open Claude Code in this folder and say:
  "read the ChannelForge folder and set it up for me"

Claude will do the rest: check your computer, ask a few questions
about the channel you want, and set everything up — without touching
any of your existing projects or settings.

Requirements: macOS + Claude Code (the CLI or desktop app with file
access — NOT the web chat). Full list: ChannelForge/setup/01-REQUIREMENTS.md
