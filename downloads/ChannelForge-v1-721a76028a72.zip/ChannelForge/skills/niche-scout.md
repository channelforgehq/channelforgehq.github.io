---
name: channelforge-niche-scout
description: Find and validate a faceless YouTube niche. Use on pipeline step 1.1 whenever the user asks to find, compare or validate a channel niche.
---

# Niche Scout

## When
Pipeline Phase 1 (step 1.1–1.2). Also when the user wants a second channel or doubts their current niche.

## Method

1. **Interview first** (2 minutes): user's interests (they'll make 20+ videos — boredom kills channels before the algorithm does), language, rough monetization hopes.
2. **Generate 8–12 candidates** biased toward formats proven to work faceless: history mysteries, "how X worked before Y", psychology of everyday behavior, origins of ordinary things, engineering disasters, money/business stories, science explainers.
3. **Score each candidate** against the six gates:

| Gate | Pass condition |
|---|---|
| Evergreen | topic still searched in 5 years; no news-cycle dependency |
| Faceless-fit | works as AI images + voiceover, no on-camera authority needed |
| Demand proven | videos with 100K+ views exist in the niche (competition = confirmed demand, NOT a blocker) |
| Small channels live | in the last ~6 months, 1–50K-sub channels got outlier views here. All-giants + fresh small attempts at double-digit views = MONOPOLIZED → NO-GO |
| Creator stamina | user says the topic won't bore them by video 20 |
| Advertiser appeal | note the rough CPM tier; inform, don't decide by it |

4. **Verify with real searches**, not from memory: run actual YouTube searches for the top candidates; name the example videos (title, channel size, views). No data → say "couldn't verify, here's how to check", never invent numbers.

## Output format

Top-3 cards, one screen each:

```
NICHE: ___
Evergreen: yes/no — why
Proof of demand: 2–3 real examples (title · channel size · views)
Small-channel test: PASS/FAIL — examples
Risks: monopolization / policy sensitivity / production complexity
Verdict: GO / NO-GO
```

**The user picks — never pick for them.** Write the choice to `channel-profile.md`.
