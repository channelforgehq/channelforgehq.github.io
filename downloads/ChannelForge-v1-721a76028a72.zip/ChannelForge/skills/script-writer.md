---
name: channelforge-script-writer
description: Retention-engineered script writing — open loops, but/therefore structure, re-hook, anti-slop. Use on pipeline step 3.1 for every script.
---

# Script Writer

## When
Step 3.1. Inputs required before writing a word: approved topic, approved title, approved thumbnail brief (its palette and promise), `channel-profile.md` (length target, language, tone, character rules).

## Retention architecture (the priority — above "beautiful writing")

**Open loops — the main retention tool:**
- The video's central question opens in the hook and closes ONLY in the final block.
- Every block ends on a hook into the next: a new question, a withheld detail, "but what they found next was stranger".
- Mid-video re-hook (~4 min for a 9-min video): restate the main promise + raise the stakes.
- Partial payout in the middle: a small answer that births a bigger question.

**But/therefore, never and-then:**
- Blocks connect through conflict: "experts believed X — BUT the evidence showed Y — THEREFORE Z."
- Test: if two adjacent paragraphs can swap places without losing meaning, the structure is flat. Rewrite.

**Concreteness:**
- Numbers, names, places, dates instead of abstractions: not "people long ago" but "a hunter, forty thousand years ago, in a cave in southern France".
- Every 30–60 seconds: a fact-jab the viewer will want to retell.
- The viewer must think "wait, WHAT?" at least 3 times, spread evenly.

**Language:**
- Short sentences, active voice, second person — the viewer is inside the story.
- Every sentence either moves the story or opens/closes a loop. Otherwise delete it.
- FORBIDDEN: a summary up front, repeating what was said, "as we mentioned", long enumerations.

**Ending:**
- The main promise pays out only in the last block.
- After the payout: a bridge to the channel's next video (open a NEW loop) + the ask. Maximum 30 seconds from answer to end — never coast.

**CTA placement:** subscribe CTA inside block 3 (~1 min in, AFTER the first payoff); comment-bait question in the final block.

**Visuals note:** numbers and statistics live in the VOICE. Every scene beat maps to one image; there are no text slides in this system. Hook-block scenes must match the thumbnail palette (step 2.4).

## Character rule (if the profile has a recurring character)
Respect the character's context boundaries from `channel-profile.md` (e.g., a period character appears ONLY in scenes set in their period; scenes addressing the modern viewer use no character or a neutral one). Mark each scene's context while writing — Phase 4 checks it.

## Retention checklist (run after the draft; all 7 must pass)
1. First sentence breaks an expectation? Hook free of background and definitions?
2. Central question opened in the hook, closed only in the final block?
3. Every non-final block ends on a hook?
4. Re-hook present mid-video?
5. But/therefore connections, no and-then chains?
6. ≥3 "wait, WHAT?" facts, evenly spread?
7. Is there a sentence that can be deleted without loss? Delete it and re-check.

## Anti-slop pass (mandatory, after the checklist)
Re-read as an editor hunting AI tells: formulaic transitions ("let's dive in", "but here's the thing" more than once), empty superlatives, symmetric sentence rhythms, adjective stacking. The text must sound like one person telling one story. Fix, then deliver.

## Delivery
The script table (`# | voiceover text | scene image`) + the line `Step 3.1 · skills used: script-writer · checks passed: retention 7/7, anti-slop`. Never show a draft that hasn't passed both.
