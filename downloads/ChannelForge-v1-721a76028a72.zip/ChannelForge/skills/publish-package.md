---
name: channelforge-publish-package
description: Upload metadata packages — titles, descriptions, tags for the long-form and its shorts, with the self-check list. Use on pipeline step 6.1.
---

# Publish Package

## When
Step 6.1 only — when the video is rendered, the thumbnail is done and upload is actually planned. Never during editing.

## Long-form description structure (strict order, all blocks)

1. **Hook** — 2–3 lines containing a real search query; the description STARTS with it (visible before "...more" — the first thing both viewer and algorithm read). Keywords from the tags must appear in the first 200 characters. Do NOT repeat the title as the first line — the viewer sees the title right above; repeating it burns the visible lines.
2. **Chapters** — right after the hook, one line per block, `0:00 Chapter name`. Timings come from `timestamps.json` (real audio), never estimated by eye. If the user opted out of chapters — skip, don't fake.
3. **Context** — 2–3 sentences on what the video covers.
4. **`What you'll learn:`** — 4–6 bullets with concrete facts (not teases).
5. **Sources block** (for research-based niches) — author, year, title, publication. **NO external URLs** in this block: upload tools flag and block descriptions with them.
6. **CTA** — the comment-bait question.
7. **How this was made** — one honest line (AI visuals + TTS voice), consistent with the synthetic-content disclosure.
8. **Channel link** — `Subscribe for more: <channel URL from profile>` — at the end of EVERY description, always.
9. **Hashtags** — see tag rules.

## Tag & hashtag rules (the most commonly violated block — check twice)
- ALL hashtags lowercase. Uppercase letters in hashtags are forbidden.
- Comma-space separated, 8–10 total; the first ones = exact search phrases from the title; include the channel's signature hashtag (from profile).
- The YouTube "tags" field gets its own list (distinct from description hashtags).

## Shorts packages
Two blocks per short: **Title** (a hook, ≤70 chars) and **Description** (3–4 lines + link to the full video + lowercase tags).
- First sentence of the description = a search query; first hashtag = broad one.
- Text is NEUTRAL — not tied to one specific moment of the clip (stays accurate if the cut shifts).
- Tags unique per short; positive/shock framing, never grim-passive.
- Max 2 shorts per topic — YouTube picks one winner and buries the rest (measured: 408 / 40 / 9 views on three same-topic shorts).

## Short title formula (validated by analytics)
```
[Something yours / about you] + [the surprising fact] + [flip]
```
A personal pronoun (You/Your) beats an impersonal fact ~2.3× on views. Weak: "They were smarter than we think" (about them). Strong: "You do this every morning. It's 40,000 years old." (about YOU).

## Self-check before showing the user (every line)
- [ ] Title uses an approved construction; construction differs from the previous 1–2 videos
- [ ] Description starts with the hook, NOT the title repeat
- [ ] Chapters from timestamps.json (if used)
- [ ] Channel link at the end
- [ ] All hashtags lowercase, 8–10, signature tag present
- [ ] Separate YouTube tags list prepared
- [ ] Shorts: Title ≤70 + neutral Description, ≤2 per topic
- [ ] No external URLs in the sources block
- [ ] No income claims, no fake urgency anywhere
- [ ] Synthetic-content disclosure mentioned in the upload instruction
- [ ] Anti-slop pass done on all public text

One failed line → fix BEFORE showing. Deliver everything as copy-paste-ready plain blocks.
