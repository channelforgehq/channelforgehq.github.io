---
name: channelforge-topic-research
description: Generate and validate video topic candidates with demand, monopolization and fact checks. Use on pipeline step 2.1.
---

# Topic Research

## When
Pipeline step 2.1, for every new video.

## Method

1. **Generate 10–15 candidates** in the channel's format (from `channel-profile.md`). Vary the angle: fear/survival, "everyone believes X but Y", body/behavior ("you do this right now"), origins, numbers that shock.
2. **Demand check per candidate** — real YouTube search, not memory:
   - Videos with 100K+ views on adjacent topics exist → demand CONFIRMED (this is a plus, not a block).
   - **Monopolization filter (mandatory):** entry allowed only if small channels (1–50K subs) got disproportionate views on this topic in the last ~6 months. Only giants ranking + fresh small attempts sitting at double digits = monopolized → drop the candidate.
   - **Exact-duplicate block:** the same wording published in the last ~2 months → drop or change the angle.
3. **Fact-check the premise** of each finalist NOW, not in the script: find 2+ independent sources for the core claim. A brilliant premise that turns out false dies here — cheaper than a dead script.
4. **Evergreen check:** will this topic matter in 5 years?

## Output format

2–3 finalists:

```
TOPIC: ___ (one-sentence premise)
Demand: examples (title · channel size · views)
Monopolization: PASS/FAIL
Premise fact-check: CONFIRMED by [sources] / SHAKY — [what's uncertain]
Angle strength: what makes viewers click when 10 similar videos exist
```

**The user picks the topic (step 2.2). Never start the title or script before they do.**

## Hard rules
- Every number and example comes from an actual search you ran. "No data" is an acceptable answer; an invented view count is not.
- If all finalists fail fact-check — say so and generate a new batch. Don't soften a SHAKY into a CONFIRMED.
