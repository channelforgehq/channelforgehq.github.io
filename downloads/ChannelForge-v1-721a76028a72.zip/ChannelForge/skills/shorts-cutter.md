---
name: channelforge-shorts-cutter
description: Pick the strongest shorts moments from a finished video and define their cuts. Use on pipeline step 5.3.
---

# Shorts Cutter

## When
Step 5.3, after the long-form passed the first-minute test. **Claude picks the moments — not the user** (the user is too close to the material; the skill's criteria beat gut feeling).

## Selection criteria (a moment qualifies only if ALL hold)
1. Hook lands within the FIRST 2 SECONDS of the cut — a "wait, WHAT?" fact or a flipped perspective.
2. Self-contained at 20–60 s: understandable without the full video.
3. Opens a loop that the FULL video closes — teases, never spoils the ending.
4. **Loopability:** the ending splices back into the beginning so a rewatch feels natural. Looped shorts show >100% retention — the single strongest signal this format has.
5. Visual variety inside the cut (≥3 scene changes).

## The proven hook shape for shorts
`What if [common belief] was actually [radical flip]?` — or a flat belief-flipping statement ("X was never about Y"). Measured on a live channel: 63.6% "stayed to watch" vs a 24–29% channel norm. Use this shape or justify why not.

## What NOT to bet on
Educational-teaser shorts almost never get SHARED — the growth levers are SAVES and REWATCHES (loops), not shares. Don't chase share-bait; close the loop instead.

## Method
1. Read the script table; shortlist 4–5 candidate moments; score each against the 5 criteria.
2. Deliver the top 2 (more only if the user asks; never more than needed — and remember: max 2 shorts per topic, YouTube buries the rest):

```
SHORT 1: [moment name]
Scene range: NN–NN
Why it grips: [criterion hits]
Loop point: [how the end feeds the start]
```

3. Generate subtitles: `python3 scripts/shorts-subtitles.py videos/NN-topic <range1> <range2>` → `short-N-subs.srt` (timecodes from zero).

## Hard boundaries
- Cutting technique is Phase 6 (letterbox 9:16, NEVER zoom-crop).
- Titles/descriptions/tags are step 6.1 (publish-package skill) — not here.
