---
name: channelforge-thumbnail-brief
description: Thumbnail concepts (before the script) and the final thumbnail prompt (after the edit). Use on pipeline steps 2.4 and 5.2.
---

# Thumbnail Brief

## When
Step 2.4 — concepts + palette, BEFORE the script (the hook scenes inherit this palette; never swap this order). Step 5.2 — the final generation prompt, after the video passed the first-minute test.

## Step 2.4 — Concepts

**Information-split rule (mandatory):** the title already says WHAT → the thumbnail adds EMOTION and a VISUAL QUESTION. The thumbnail never duplicates the title's words; together they form one incomplete story that only the click completes.

Develop **4–5 concepts**, each hitting a different psychological trigger:
1. Personal involvement ("that's me / I do that")
2. Comparison / paradox / impossible-things-side-by-side
3. Recognition / cultural reference
4. Atmosphere / dread / a collective gaze into the camera
5. Visual shock / surrealism

Per concept: focal point (what the eye hits in <1 s), emotion, palette (2–3 dominant colors), text overlay (≤3 words or none), read-speed estimate.

**A face with a strong emotion adds measurably to CTR** (neutral faces perform WORSE than no face) — include a face-forward concept when the topic allows.

Present as a comparison table. **The user picks.** Write the chosen concept + palette into the video's project file — Phase 4 will color the hook scenes with exactly this palette. Style stays the CHANNEL's canon (from `channel-profile.md`) — a thumbnail "prettier" than the video (different render style) is a broken promise and kills retention at the style switch. The only allowed deviation: a dark/night mood version of the same style for dark-themed videos.

## Step 5.2 — Final prompt

Written for the `image_provider` from `channel-profile.md` (provider contract). The prompt includes:
- Channel style wrapper + chosen concept
- Main subject: exact pose, emotion, angle
- The eye-catch element (what reads first)
- Palette as explicit colors, role of each
- Composition: rule of thirds, the eye's route
- Explicit negative list (what NOT to draw)
- **No text in the AI image** — generators mangle letters. Text (if the concept has it, ≤3–5 words) is overlaid afterwards: Claude writes a small PIL script in the video folder (`thumbnail-text.py`) that fits the font, checks the edges and outputs `thumbnail.png` at 1280×720.

**Final check:** shrink to phone size (~120 px wide) — still readable? If not, simplify: one subject, bigger, fewer elements.
