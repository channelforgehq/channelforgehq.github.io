---
name: channelforge-hooks-and-titles
description: Title formulas and 30-second hook frameworks engineered for Browse/Suggested traffic. Use on pipeline steps 2.3 (title) and 3.1 (script hook).
---

# Hooks & Titles

## When
Step 2.3 (title variants) and step 3.1 (the script's opening 30 words). The title and the hook are ONE promise told twice — never write them in isolation from the thumbnail brief.

## Titles

**Primary criterion: curiosity in the recommendations feed.** Faceless niches live on Browse/Suggested, not search. A searchable phrase is a bonus, not the goal.

**Constructions (rotate — never two consecutive videos on the same formula; YouTube treats same-template titles as similar content and cannibalizes them):**

```
QUESTION-PARADOX:   What Did [subject] Do When [problem]? ([twist])
BELIEF-FLIP:        [Subject] Never [expected thing]. [Shocking stat]. Yours Is [contrast].
"NO X" + RESULT:    No [tool] for [huge timespan]. They Were Still Never [expected failure].
PERSONAL "YOU":     You [do familiar thing] Exactly Like [distant subject]
FACT + INTRIGUE:    The Real #1 [thing] of [subject] (It Wasn't [obvious guess])
```

**Per-variant delivery:** the construction used, the curiosity mechanism, CTR-potential estimate (mark it "estimate"), and — if the channel language differs from the user's own language — a translation for the user's understanding.

## Hooks (first 30 words of the script)

Rules, all mandatory:
- Start MID-FACT: the most intriguing paradox first. No greetings, no context, no "in this video".
- First sentence breaks an expectation (a confident claim the viewer half-disbelieves).
- Contains: a concrete payout promise ("by the end you'll know X") + why it touches the viewer personally.
- The hook honors the thumbnail: the first 30 seconds VISUALLY and tonally deliver what the thumbnail promised. Mismatch = retention collapse in minute one (measured: 100%→30%).
- FORBIDDEN in hooks: generalities ("people have always wondered..."), definitions, historical background.

**Hook mechanisms** (pick per topic; explain your choice):
| Mechanism | Use when | Avoid when |
|---|---|---|
| Shock/Contradiction | strong counterintuitive fact exists | the claim needs a paragraph of setup |
| Problem-Agitation | viewer has a felt pain | topic is pure curiosity, no pain |
| Story-Open (in medias res) | a concrete scene exists (person, place, moment) | no narrative material |
| Curiosity-Gap | the answer is genuinely surprising | the gap would feel like clickbait |
| Social Proof | ONLY with real numbers you can show | always otherwise — new channels have no authority |

## Output format
2–3 title variants (construction labeled) + recommended one with reasoning. For hooks: the full 30-word opening + mechanism + one-line "why this holds".
