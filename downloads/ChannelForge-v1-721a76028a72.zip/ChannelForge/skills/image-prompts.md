---
name: channelforge-image-prompts
description: Scene image prompts and motion prompts with per-provider adapters (Midjourney, Leonardo, GPT, others). Use on pipeline step 4.1 and for any prompt fix during step 4.4.
---

# Image Prompts — core rules + provider adapters

## The provider contract (read first, every time)
Before writing ANY prompt: read `channel-profile.md` → `image_provider`, `motion_provider`, `motion_scope`, `visual_style`, `character`. Use the matching adapter below. Name the output file with the provider: `prompts-NN-<provider>.md`. A prompt in another provider's syntax = pipeline Rule Zero violation.

---

## CORE (applies to every provider)

1. **Style wrapper.** Every prompt STARTS with the channel's style wrapper from the profile (e.g. `flat 2D cartoon style, clean bold outlines, soft cel shading, warm friendly tone`). One canon for thumbnail, hook and body — a "prettier" hook than the body breaks the promise and drops retention at the style switch. If the generator returns something more polished than the canon (glow, soft shadows, detailed rendering), regenerate — do not accept.
2. **Scene-colored backgrounds, always.** The background is part of the scene (forest, night fire, workshop, sky...) and is described IN the prompt. Never a white/empty studio void — even a "portrait" gets a minimal colored environment. Hook-block scenes use the thumbnail palette locked in step 2.4 (dark thumbnail → dark/dramatic hook scenes in the SAME style; the dark→normal transition at block 1→2 works as an "awakening", that's fine).
3. **Character era/context rule.** If the profile has a recurring character with context boundaries — check EVERY scene's text: does this scene belong to the character's world? Scene addresses the modern viewer / "you" / "today" → the character is NOT in the frame (use hands, objects, icons, schemes — or a neutral person without the character reference). Run this check per scene and mark it in the prompt file.
4. **Character consistency** — via the provider's mechanism (see adapters). Applies only when a human character is in the scene; anthropomorphic objects (a tooth with eyes) are not a character.
5. **16:9**, composition with breathing room. Never bake zoom/motion into a still — the user adds camera moves in the editor.
6. **Pattern interrupt** roughly every 30 seconds of runtime: one deliberately stronger visual (scale jump, angle change, color hit).

## MOTION PROMPTS (per `motion_scope`: hook | full | none)

For each flagged scene, a second line — the motion prompt for the user's image-to-video service:
- LIGHT movement only: slow camera push-in, parallax, fire flicker, drifting smoke, swaying hair, breathing frame.
- NO head/body turns, no walking toward camera — image-to-video melts faces on strong motion.
- Do NOT describe the character's appearance — it's already fixed in the source image. Motion words only.
- 5–10 seconds per clip; the clip replaces its static scene at assembly.

---

## ADAPTERS — images

### Midjourney (V7) — default
```
[style wrapper], [scene with environment] --ar 16:9 --v 7
```
- Character in scene → append `--oref <master-image-URL> --ow 100`. (V7 uses omni-reference; `--cref/--cw` ERROR on V7.)
- `--ow` tuning: 100 default · 200–300 if the face drifts · 50–70 to change pose/outfit · in multi-person scenes use `--ow 50` and describe others as explicitly different people.
- The character master image is generated once during customization and its URL stored in `channel-profile.md`.

### Leonardo
- Pick one model/preset at customization and STICK to it for the whole channel (model switch = style switch).
- Character consistency: a character reference image + fixed seed noted in the profile; keep guidance moderate — high guidance fights the style wrapper.
- Same core rules; write prompts as comma-separated descriptors, negative prompt carries the "no white background, no realism" guard.

### GPT / DALL-E (conversational generators)
- Prompts are written as full sentences (these models follow prose better than tag soup).
- Character consistency: a **text passport** — a fixed 2–3-sentence description of the character (face, hair, build, clothing) stored in `channel-profile.md`, pasted verbatim into every character scene.
- Explicitly restate the style wrapper and "16:9" every time; these models drift without repetition.

### OTHER (any provider the user names)
1. Web-search the provider's current prompt syntax and consistency mechanism — do not guess from memory.
2. Run ONE test scene with the user, compare against the channel canon.
3. Append a new adapter section to this file (their syntax, their consistency trick) — the product is yours to extend.

## ADAPTERS — motion

### Veo
Prose description of the motion, one sentence, camera term first ("Slow push-in on...; embers drift"). Duration per the service tier.

### Runway
Short comma phrases; use camera-motion keywords (push-in, parallax) + intensity low. Fix seed if regenerating a scene.

### OTHER
Same self-extension protocol as images: search the syntax, test one clip, write the adapter in.

---

## Delivery
`prompts-NN-<provider>.md`: numbered scenes matching the script table, per scene — image prompt (+ motion line if flagged), character-context mark (past/modern/none). End with: `Step 4.1 · skills used: image-prompts (<provider> adapter) · checks passed: provider match, backgrounds, character contexts`.
