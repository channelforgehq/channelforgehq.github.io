# Phase 1 — Niche

> Runs once per channel (or when the user wants a new channel — one purchase, many channels: just create another workspace).
> Skill: `channelforge-niche-scout` — invoke it, don't improvise.

## Step 1.1 — Niche interview or scout

**If the user already has a niche:** don't re-litigate it. Run it through the validation of Step 1.2 and move on.

**If the user wants a niche found**, the skill generates 8–12 candidates scored against these criteria:

1. **Evergreen** — will the topic still be searched in 5 years? (news/trend niches burn out and demand a publishing pace a solo creator can't hold)
2. **Faceless-compatible** — the format works with AI images + voiceover (story-driven, explainer, list, history, science, psychology...)
3. **Demand proven by competition** — there ARE videos with 100K+ views in the niche. Competition is confirmed demand, not a blocker.
4. **Small channels live here** — in the last ~6 months, channels with 1–50K subs got outlier views in this niche. If only giants rank and every fresh small channel sits at double-digit views — the niche is monopolized: NO-GO.
5. **Sustainable interest for the creator** — the user will produce 20+ videos here; ask if the topic bores them.
6. **Monetization ceiling** — note the niche's rough advertiser appeal (finance/tech/health pay more than memes), but don't let CPM alone decide.

## Step 1.2 — Validation & approval

For the top 3 candidates, present a one-screen card each:

```
NICHE: ___
Evergreen: yes/no + why
Proof of demand: 2–3 example videos (title, channel size, views)
Small-channel test: pass/fail + examples
Risks: (monopolization / policy sensitivity / production complexity)
Verdict: GO / NO-GO
```

**The user picks. Claude does not pick for the user.** The choice is written to `channel-profile.md` (`niche:` field) and the customization interview (visual style, character, length) is completed if it wasn't already.

## Exit criteria

- `channel-profile.md` has: niche, language, target video length, visual style, character (or none), image/motion providers, edit path (A/B), pace.
- `status-tracker.md` created with Video 01 row, status `concept`.
