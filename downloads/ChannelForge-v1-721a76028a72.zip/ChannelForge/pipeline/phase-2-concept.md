# Phase 2 — Concept (topic → title → thumbnail brief)

> The thumbnail brief is part of the CONCEPT, not the packaging. It's locked BEFORE the script so the hook scenes inherit its palette and promise. This ordering is the system's core know-how — never swap it.

## Step 2.1 — Topic candidates

**Skill: `channelforge-topic-research` (mandatory).**

1. Generate 10–15 topic candidates in the channel's format (from `channel-profile.md`).
2. Check competition per candidate in YouTube search: competition = **confirmed demand** (a plus, not a block).
3. **Monopolization filter (mandatory):** entry is allowed only if small channels (1–50K subs) got disproportionate views on this topic in the last ~6 months. All-giants search results + fresh small attempts at double-digit views = monopolized, skip.
4. **Exact-duplicate block:** same wording published in the last ~2 months = block (wait or change the angle).
5. Fact-check the premise of each finalist: the topic must survive research. A juicy premise that turns out false dies here, not in the script.

**Deliver:** 2–3 finalists with scores. **The user picks (Step 2.2).**

## Step 2.3 — Title

**Skill: `channelforge-hooks-and-titles` (mandatory).**

1. 2–3 variants. Primary criterion: **curiosity in the recommendations feed** (paradox question, belief-flipping statement, personal "You") — faceless niches live on Browse/Suggested, not search. A searchable phrase is a bonus, not a requirement.
2. Estimate CTR potential per variant; check title constructions rotate between videos (no two consecutive videos with the same formula).
3. User approves one.

## Step 2.4 — Thumbnail BRIEF (before the script — always)

**Skill: `channelforge-thumbnail-brief` (mandatory).**

1. 3–5 thumbnail concepts. **Information-split rule:** the thumbnail never duplicates the title — together they form one incomplete story the viewer must click to finish.
2. Each concept: focal point, emotion, palette (2–3 dominant colors), text overlay (≤3 words or none).
3. User picks a concept. **Its palette is written into the video's project file — the hook scenes (block 1) of Phase 4 MUST use this palette.** A viewer who clicks the thumbnail must land in the same visual world.
4. Final thumbnail image is generated later (Step 5.2), after the video is assembled and approved — the brief now, the render then.

## Exit criteria

- Topic, title and thumbnail brief approved and written to the video's project file (`videos/NN-topic/project.md`).
- `status-tracker.md` row updated to `script`.
