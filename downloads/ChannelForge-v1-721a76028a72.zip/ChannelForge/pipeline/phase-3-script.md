# Phase 3 — Script

> Skill: `channelforge-script-writer` (mandatory — the retention rules live there).
> Target length, language and tone come from `channel-profile.md`. Default structure below assumes ~8–10 minutes; the skill scales block count for other lengths.

## Step 3.1 — The script

**Structure (default for ~9 min ≈ 1250–1300 spoken words):**

- **HOOK — first 30 words.** The video's central question or belief-flip, stated immediately. No greetings, no "in this video". The hook's imagery matches the thumbnail palette (locked in Step 2.4).
- **6 blocks**, each ends on a hook into the next (open loop). "But / therefore" logic between beats — never "and then".
- **Re-hook** at block 3/4 boundary (~4 min): a second strong open loop for the mid-video dip.
- **CTA placements:** subscribe CTA inside block 3 (~1 min in, after the first payoff — never before value is delivered); a comment-bait question in block 6.
- **Numbers and statistics live in the voiceover, not on screen.** Every scene beat maps to ONE image. There are no text slides in this system.

**Script file format** — a table in the video folder (`script-NN-DATE.md`):

| # | Voiceover text | Scene image (one line: what the viewer sees) |

**Retention checklist (all 7 must pass before showing the user):**
1. Hook = first 30 words, central question stated
2. Every block ends on an open loop
3. Re-hook present at ~4 min
4. No block is pure exposition — each has a "wait, what?" fact
5. "But/therefore" transitions, no "and then" chains
6. Subscribe CTA after first payoff; comment question near the end
7. Anti-slop pass done (see below)

**Anti-slop pass:** re-read the whole text and remove AI-writing tells (formulaic transitions, empty superlatives, symmetric sentence patterns). The text must read like a person telling a story, in the channel's language.

## Step 3.2 — Voice text file

From the approved script, generate `voice-NN-DATE.md`: the voiceover text split into blocks, formatted for the user's TTS service:

- No em-dashes (most TTS engines choke on them) — restructure sentences instead
- Numbers written as words ("seventeen thousand", not "17,000")
- One block = one file to generate = one audio file (`voice/1.mp3 … 6.mp3`)
- At the top: a reminder of the user's voice/settings from `channel-profile.md`

## Exit criteria

- Script passed all 7 checks, user approved.
- `voice-NN-DATE.md` ready for the user's TTS service.
- Status → `assets`.
