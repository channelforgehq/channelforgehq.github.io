# Phase 5 — Edit, first-minute test, thumbnail, shorts moments

> The edit path (A or B) is set in `channel-profile.md`. Both consume the same inputs: `images/`, `images/motion/`, `voice/`, `_assembly/sync-map.json`.

## Path A — DaVinci Resolve Studio (via MCP)

Requires: DaVinci Resolve **Studio** + the DaVinci MCP server (installed during setup if chosen).

**5.A1 — Assemble:**
```
python3 scripts/assemble-davinci.py videos/NN-topic
```
Reads `sync-map.json` → imports PNGs (already `001x.png`, no symlinks needed) → creates the project at the profile's resolution/fps → places each image exactly at its `start_frame` (length = gap to the next scene) → motion clips replace their static scenes → voice on track 1, looped music at −20 dB on track 2.
**Zoom moves:** the user adds them by hand in DaVinci afterwards — the script never bakes zoom.

**5.A2 — Drift auto-check:** the script reads actual timeline positions back and compares with the audio. Report "average drift X.XXs, no desync" or list scenes drifting >0.3 s.

**5.A3 — Render:** same script with `--render` → `videos/NN-topic/video.mp4`.

## Path B — timeline project file (any editor, Studio not needed)

**5.B1 — Generate the timeline:**
```
python3 scripts/generate-fcpxml.py videos/NN-topic
```
Produces `timeline-<video>-<date>.fcpxml` with EVERYTHING already in place on the tracks: every scene image (or motion clip) at its exact frame on the video lane, the voiceover on audio lane 1, looped music at −20 dB with a fade-out on lane 2. Nothing is pre-rendered on purpose — **the edit stays editable**: if a scene drifted off its phrase, the user just drags it in the editor.

**5.B2 — Import & polish (user):** DaVinci Resolve (free edition is fine) → File → Import Timeline → XML — or Final Cut / Premiere. Check the music level, add zoom moves by hand, nudge any drifted scenes. The script prints a report of scenes shorter than 1.5 s — eyeball those first.

**5.B3 — Render (user):** render to `video.mp4` from the editor.

## Step 5.1 — ⛔ FIRST-MINUTE TEST (blocking — no exceptions)

No technical check catches "boring". The user watches the FIRST 60 SECONDS as a viewer, not as the author, and answers:
1. At 0:15 — is there a reason to stay? (has the video's central question landed?)
2. At 0:30 — has the picture changed enough that the eye isn't bored?
3. At 0:45 — is a loop open ("what happens next?")?
4. Would you swipe away? If yes — at which second?

**Blocking rule:** "I'd swipe" = the hook gets rebuilt (text / images / motion) and the video is NOT published. Cheaper than burning the algorithm's first impression.

## Step 5.2 — Final thumbnail

Now that the video exists and passed the test: generate the thumbnail from the Step 2.4 brief. **Skill: `channelforge-thumbnail-brief`**, provider = `image_provider` from the profile. Claude writes the detailed prompt (concept + palette + character if any); the user generates and picks. Verify at small size: readable as a 120-px-wide rectangle on a phone.

## Step 5.3 — Shorts: moment selection + subtitles

**Skill: `channelforge-shorts-cutter` (mandatory). Claude picks the moments — not the user.**

1. From the script, select the 2 most gripping 20–40 s moments: hook within the first 2 seconds, a "wait, WHAT?"-fact, an open loop, teases the full video, doesn't spoil the ending, self-contained.
2. Deliver: moment + exact scene range + why it grips.
3. Generate subtitles:
```
python3 scripts/shorts-subtitles.py videos/NN-topic 12-34 80-100
```
→ `short-1-subs.srt`, `short-2-subs.srt` (timecodes from zero).

Titles/descriptions/tags for shorts are NOT written here — that's Phase 6, when upload is actually planned.

## Exit criteria

- `video.mp4` rendered, first-minute test passed, thumbnail approved, 2 shorts moments + subtitles ready. Status → `publish`.
