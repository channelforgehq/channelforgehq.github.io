# Phase 4 — Assets (prompts → voice → images → motion → sync map)

> Mid-tier model is fine for this phase — it's mechanics, not creativity (except 4.1 which uses the prompts skill).

## Step 4.1 — Image prompt file

**Skill: `channelforge-image-prompts` (mandatory). Provider contract applies:** read `channel-profile.md` FIRST; every prompt is written for the `image_provider` set there, using that provider's adapter section. File is named with the provider: `prompts-NN-<provider>.md`.

Rules (provider-independent core):
1. One prompt per scene, in scene order, numbered to match the script table.
2. **Scene-colored backgrounds** — the background carries the scene's mood; never a sterile white studio void. (Block 1 scenes use the thumbnail palette from Step 2.4.)
3. **Recurring character** (if the profile has one): apply the provider's character-consistency mechanism (reference image / seed / text passport — per adapter). Character appears ONLY in scenes where the profile's character rules allow it.
4. Aspect 16:9. Composition leaves breathing room — the user adds zoom moves in the editor; never bake zoom into the image.
5. A strong visual pattern-interrupt roughly every 30 seconds of runtime.

**Motion prompts** (per `motion_scope` in the profile):
- `hook` (recommended default): every block-1 scene gets a second line — a motion prompt for image-to-video in the user's `motion_provider`. LIGHT movement only: parallax, fire flicker, drifting smoke, breathing camera. No head/body turns (image-to-video melts faces on strong motion). No character description in the motion prompt — the character is already fixed in the source image.
- `full`: every scene gets a paired motion prompt.
- `none`: skip.

## Step 4.2 — Voiceover (user, their own service)

The user generates ALL blocks at once in their voice service (site, bot — whatever they use; no API needed), saves as `voice/1.mp3 … 6.mp3` in the video folder. Why all at once: the script was written to a word target, so total runtime lands near the goal; real audio beats any prediction.

## Step 4.3 — Runtime check

Measure total duration of the audio files + inter-block pauses against the profile's target range. Out of range → add/remove one fact-jab in ONE block, re-voice only that block.

## Step 4.4 — Images (user, their provider)

Generate strictly in prompt order, download in order to `~/Downloads/`. Claude fixes prompts on request — through the skill's adapter, never freehand.

## Step 4.5 — Motion clips (if motion_scope ≠ none)

Run the flagged scenes through the user's image-to-video service using the paired motion prompts (5–10 s each, from the FINISHED scene images). Save to `images/motion/`, keeping scene numbers.

## Step 4.6 — Rename assets

```
python3 scripts/rename-assets.py videos/NN-topic
```
Cross-checks voice vs script, sorts downloads by time, converts webp→png, moves to `images/` as `001x.png, 002x.png…` (the `x` suffix stops editors from grouping them into an image sequence). Before running: count PNGs in Downloads vs expected scene count.

## Step 4.7 — Control sheet (auto-check)

The rename script generates `control-sheet.html`. Claude inspects it silently: all green → move on without bothering the user; red (missing file) or orange (wrong folder) → stop and show exactly what's wrong.

## Step 4.8 — Transcription

```
python3 scripts/transcribe-audio.py videos/NN-topic
```
Whisper word-level timestamps → `timestamps.json`.

## Step 4.9 — Anchor mapping

```
python3 scripts/build-sync-map.py videos/NN-topic
```
Takes `timestamps.json` + anchor phrases from the script table → finds each phrase in the transcript → writes `_assembly/sync-map.json`: scene → exact frame. This map drives the edit in Phase 5.

## Exit criteria

- All assets in place, control sheet green, `sync-map.json` built. Status → `edit`.
