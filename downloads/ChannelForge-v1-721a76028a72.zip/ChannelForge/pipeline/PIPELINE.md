# ChannelForge — The Production Pipeline

> This file is the map. Each phase has its own file with full instructions — read ONLY the phase you're working on.
> Every step runs strictly in order. Skipping a step is a production error.
> All channel-specific values (niche, style, providers, video length) come from `channel-profile.md` in the user's workspace — never from this file, never from memory.

## ⛔ RULE ZERO — IRON RULES (violation = redo everything)

1. **Steps run in order.** Step N starts only after the user approved step N−1. The thumbnail BRIEF comes BEFORE the script — always.
2. **Nothing from memory.** Where a step names a skill — invoke it BEFORE producing the result. Writing prompts, hooks, scripts or metadata "from memory" instead of via the skill = the step was not done.
3. **One step at a time.** Do the step → show the user → wait for approval → next step.
4. **Not sure which step you're on?** Open this file and the workspace `status-tracker.md`. Never guess.

## ⛔⛔ NO-GUESSING PROTOCOL (binding for ANY model on ANY step)

1. **No data from thin air.** Every number, timecode, filename, status or link comes from a project file, a script's output, or a skill. No source → write "no data, needs checking: [how]" — never substitute a plausible value.
2. **Before delivering any result**, state one line: `Step N · skills used: [...] · checks passed: [...]`. No line = result not accepted.
3. **The user sees only the final version** that passed the step's checklists. No drafts, no unproofed variants.
4. **Doubt = stop.** Open the phase file and quote the rule; don't act "from memory".
5. **Pre-publish cross-check is mandatory** (Phase 6): title ↔ description ↔ tags ↔ thumbnail ↔ video file must all belong to the SAME video.
6. **Analytics data** — only from YouTube Studio screenshots or API. Mark estimates as "estimate".
7. **Platform policies change.** Anything involving YouTube rules (monetization, synthetic-content labels, Shorts rules) — verify with a current web search, not from memory and not from this file.

## The provider contract

Before generating ANY prompt (image, motion, thumbnail), read `channel-profile.md` and use the adapter for the provider set there (`image_provider`, `motion_provider`, `motion_scope`). Prompt files are named with the provider (e.g. `prompts-scene-01-leonardo.md`). A prompt written for a different provider than the profile = Rule Zero violation.

## Phases

| Phase | File | What happens | Model tip (cost saver) |
|---|---|---|---|
| 1. Niche | `phase-1-niche.md` | Find and validate a niche | strongest model |
| 2. Concept | `phase-2-concept.md` | Topic → title → thumbnail brief → hook direction | strongest model |
| 3. Script | `phase-3-script.md` | Retention-structured script + voice text | strongest model |
| 4. Assets | `phase-4-assets.md` | Image & motion prompts, voiceover, renaming, sync map | mid-tier model is fine |
| 5. Edit | `phase-5-edit.md` | Assembly (DaVinci path A / ffmpeg path B), first-minute test, final thumbnail, shorts moments | mid-tier model is fine |
| 6. Publish | `phase-6-publish.md` | Metadata package, cross-check, upload plan, shorts, analytics | strongest model for texts |

## Master step table

| # | Step | Who | Skill required |
|---|---|---|---|
| 1.1 | Niche interview or scout | Claude + user | channelforge-niche-scout |
| 1.2 | Niche validation & approval | user decides | — |
| 2.1 | Topic candidates + demand check | Claude | channelforge-topic-research |
| 2.2 | Topic approval | user | — |
| 2.3 | Title variants | Claude | channelforge-hooks-and-titles |
| 2.4 | **Thumbnail BRIEF (before script!)** — concept + color palette; hook scenes will inherit this palette | Claude + user | channelforge-thumbnail-brief |
| 3.1 | Script (hook + blocks, retention checklist) | Claude | channelforge-script-writer |
| 3.2 | Voice text file (blocks, formatted for TTS reading) | Claude | — |
| 4.1 | Image prompt file (per scene, provider adapter, + motion prompts per `motion_scope`) | Claude | channelforge-image-prompts |
| 4.2 | Voiceover: user generates in their own service, drops files into the video folder | user | — |
| 4.3 | Runtime check against target length (from profile) | Claude | — |
| 4.4 | Images: user generates in their provider, downloads in scene order | user | — |
| 4.5 | Motion clips (if motion_scope ≠ none): image-to-video in user's service | user | — |
| 4.6 | `rename-assets.py` → ordered scene files | Claude | — |
| 4.7 | Control sheet auto-check (missing/misplaced files) | Claude | — |
| 4.8 | Audio transcription → word-level timestamps | Claude | — |
| 4.9 | Anchor mapping → scene-to-frame sync plan | Claude | — |
| 5.A | Path A: assemble in DaVinci Studio via MCP → drift check → render | Claude | channelforge MCP setup |
| 5.B | Path B: generate a ready timeline file (FCPXML) — all images, voice, music on the tracks; user imports into any editor (free DaVinci / FCP / Premiere), polishes by hand, renders | Claude + user | — |
| 5.1 | ⛔ FIRST-MINUTE TEST (blocking): user watches 60s as a viewer | user + Claude | — |
| 5.2 | Final thumbnail: prompt per brief from 2.4, generated in user's provider | Claude + user | channelforge-thumbnail-brief |
| 5.3 | Shorts: Claude picks 2 strongest moments + generates subtitles | Claude | channelforge-shorts-cutter |
| 6.1 | Metadata package: long-form + both shorts in one batch | Claude | channelforge-publish-package |
| 6.2 | ⛔ CROSS-CHECK: title↔description↔tags↔thumbnail↔file — same video? | Claude + user | — |
| 6.3 | Upload unlisted, synthetic-content disclosure, schedule | user | — |
| 6.4 | End screens, cards, pinned comment; reply to every comment first 2 hours | user | — |
| 6.5 | Shorts: cut (9:16 letterbox, never zoom-crop) and publish on cadence | user | — |
| 6.6 | 48-hour analytics + ⛔ STOP-VALVE (2 flops in a row = halt & diagnose) | Claude + user | channelforge analytics guidance |

## Dependencies note

Phase 4 transcription uses Whisper (word-level timestamps). It's installed during setup (`check-setup.sh` verifies it). If missing mid-project: `pip3 install openai-whisper`.
