# Phase 6 — Publish & learn

## Step 6.1 — Metadata package (long-form + both shorts, one batch)

**Skill: `channelforge-publish-package` (mandatory).** Run ONLY when everything is ready: video rendered, thumbnail done, both shorts cut or about to be — never during editing.

1. Long-form: title (approved in 2.3), description, tags. Description rules: first sentence = a search query a viewer would type; structured blocks (what's inside, chapters if used, channel link at the end); 8–10 lowercase hashtags.
2. Each short: title ≤70 chars, description, tags. Short descriptions are **neutral** — not tied to one moment (so they stay accurate if the cut shifts); first hashtag broad, tags unique per short.
3. Anti-slop pass on all public text.
4. **Policy check:** anything relying on current YouTube rules (synthetic-content disclosure, monetization terms) — verify by web search now, not from memory.

## Step 6.2 — ⛔ CROSS-CHECK (mandatory, blocking)

Before upload, Claude reads out loud: "File X → title Y → description's first line Z → thumbnail shows W — is this all ONE video?" The user confirms. This exists because mixed-up metadata between two finished videos is the single most embarrassing failure mode of a batch pipeline.

## Step 6.3 — Upload

User uploads `video.mp4` **unlisted**, pastes the metadata, sets the "Altered or synthetic content" disclosure to YES (AI-generated visuals), checks the Content ID / copyright tab, schedules for the channel's slot (evening in the audience's timezone, weekday — from `channel-profile.md`).

## Step 6.4 — Packaging around the video

1. End screen (last 15–20 s): one specific video + subscribe button.
2. Info card at ~50% runtime → next relevant video.
3. Pinned comment: a question about THIS video + "WATCH NEXT — [hook] 👉 [link]".
4. **First 2 hours after going live: reply to EVERY comment** — the early-engagement window measurably boosts first-wave reach.

## Step 6.5 — Shorts cut & cadence

- Cut by the scene ranges from Step 5.3, burn in the `.srt` subtitles.
- **9:16 via letterbox** (`scale=1080:-2,pad`) — NEVER zoom-crop: it destroys the image composition. `scripts/letterbox-916.sh` does it right.
- Cadence: Short #1 → +2 days → Short #2 → +2 days → the long-form goes public.
- When the long-form is live, edit both shorts' descriptions to add its link.

## Step 6.6 — 48-hour analytics + ⛔ STOP-VALVE

**48 hours after publish**, the user brings YouTube Studio screenshots (CTR, retention curve, traffic sources). Claude diagnoses the funnel: impressions → CTR → first-minute retention → average view duration, names the weakest stage, and writes ONE corrective action for the next video into `status-tracker.md`.

**STOP-VALVE:** if 2 long-forms in a row get <100 views in their first 7 days — production HALTS. No "one more video will fix it". Diagnose the funnel, form a hypothesis, change ONE variable (packaging / hook / format / niche angle), then resume. A conveyor that keeps running into zero views burns months; this valve exists because it happened to the authors of this system.

## Exit criteria

- Video and shorts scheduled/live, analytics reviewed at 48 h, one lesson written down. Status → `done`, next video starts at Phase 2.
