# Requirements — what your computer needs

> Honest list, no surprises. Claude checks all of this for you (`check-setup.sh`)
> and offers to install only what's missing.

## Hard requirements

| What | Why | If missing |
|---|---|---|
| **macOS** | v1 is built and tested on macOS only | no workaround in v1 |
| **Claude Code** (CLI or desktop app with file access) | it IS the studio — the web chat can't run scripts or manage files | claude.com/claude-code |
| **Claude subscription** that includes Claude Code usage | the pipeline runs on it | your plan, your choice |
| **ffmpeg** | audio concat, transcription prep, shorts letterbox | `brew install ffmpeg` |
| **python3** | all pipeline scripts | ships with macOS; brew if outdated |
| **faster-whisper** (`pip3 install faster-whisper`) | word-level timestamps that sync images to the voice | installed during setup |

## Subscriptions you bring (any — the pipeline adapts)

| Role | Examples | How it's used |
|---|---|---|
| **Image generation** | Midjourney, Leonardo, GPT/DALL-E, others | Claude writes prompts FOR YOUR provider; you generate on their site and drop files in the video folder. No API keys needed. |
| **Voiceover** | ElevenLabs or any TTS you like | Claude gives you the exact text per block; you generate and save as `voice/1.mp3…` |
| **Motion (optional)** | Veo, Runway, Kling, others | image-to-video for hook scenes (or the whole video — your call) |

No subscriptions yet? Start with Midjourney for images — and know you can switch
providers later with one phrase. Your tools, your budget, your choice.

## Editing — two paths, pick at customization

| Path | Needs | What you get |
|---|---|---|
| **A** | DaVinci Resolve **Studio** (the paid edition — its scripting API is what we automate) + MCP server (installed in setup) | Claude builds the timeline inside Resolve for you and can render |
| **B** | any editor: DaVinci Resolve FREE, Final Cut, Premiere | Claude generates a ready timeline file (FCPXML) — every image, the voiceover and music already on the tracks; you import, polish by hand, render |

Both paths produce the same video. A is more automated; B keeps you closest to the edit.
