#!/bin/bash
# ChannelForge environment self-check. Read-only: checks everything,
# installs NOTHING. Claude reads the output and offers to fix only
# what's missing (with your approval per item).

echo "── ChannelForge setup check ──────────────────────────"
STATUS=0

ok()   { printf "  ✅ %s\n" "$1"; }
warn() { printf "  ⚠️  %s\n" "$1"; }
fail() { printf "  ❌ %s\n" "$1"; STATUS=1; }

# OS
if [ "$(uname)" = "Darwin" ]; then
  ok "macOS $(sw_vers -productVersion 2>/dev/null)"
else
  fail "Not macOS — ChannelForge v1 is built and tested on macOS only"
fi

# Required: ffmpeg, python3
command -v ffmpeg >/dev/null 2>&1 \
  && ok "ffmpeg $(ffmpeg -version 2>/dev/null | head -1 | awk '{print $3}')" \
  || fail "ffmpeg not found (required) — install: brew install ffmpeg"

command -v python3 >/dev/null 2>&1 \
  && ok "python3 $(python3 --version 2>&1 | awk '{print $2}')" \
  || fail "python3 not found (required)"

# Whisper for transcription (either faster-whisper importable)
python3 -c "import faster_whisper" >/dev/null 2>&1 \
  && ok "faster-whisper (transcription)" \
  || warn "faster-whisper missing — needed in Phase 4: pip3 install faster-whisper"

# Optional: DaVinci Resolve Studio (edit path A)
if [ -d "/Applications/DaVinci Resolve/DaVinci Resolve.app" ]; then
  ok "DaVinci Resolve installed"
  if [ -f "/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion/fusionscript.so" ]; then
    ok "Resolve scripting library present (Studio feature)"
  else
    warn "Resolve scripting library not found — edit path A needs the STUDIO edition; path B (ffmpeg) works regardless"
  fi
  command -v python3.11 >/dev/null 2>&1 \
    && ok "python3.11 (Resolve scripting)" \
    || warn "python3.11 missing — needed only for edit path A: brew install python@3.11"
else
  warn "DaVinci Resolve not found — edit path B (ffmpeg) will be used; you can add Resolve later"
fi

# Image/motion/voice providers are subscriptions, not software — Claude asks
# about them in the customization interview (03-CUSTOMIZE.md), not here.

echo "──────────────────────────────────────────────────────"
if [ $STATUS -eq 0 ]; then
  echo "Result: required tools OK. Warnings (if any) are optional features."
else
  echo "Result: required items missing — Claude will offer fixes one by one."
fi
exit $STATUS
