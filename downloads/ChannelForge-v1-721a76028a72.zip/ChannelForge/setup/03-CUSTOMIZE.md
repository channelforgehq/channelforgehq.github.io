# Customization interview — for Claude

> Run as a conversation, not a form: one question at a time, suggest sensible
> defaults, accept "I don't know — you pick" (then pick and say why). Answers go
> into the workspace `channel-profile.md` (template: templates/channel-profile.md).
> EVERY pipeline step reads that file — this interview is where the product adapts
> to THIS user. Re-runnable anytime: "change my style" → update the profile.

## The 11 questions

1. **Niche.** Got one already? → note it, validation happens in Phase 1.
   Want one found? → Phase 1 starts with the niche-scout skill after setup.
2. **Channel language.** Default English (largest audience/CPM). Any language works —
   scripts are written by Claude, the voice is TTS.
3. **Format.** Long-form target length (default ~9 min), videos per week (be honest
   about time), shorts per video (default 2).
4. **Visual style.** Presets: `flat 2D cartoon` (default — cheap to keep consistent),
   `realistic illustration`, `minimal graphic`. Or describe your own. Locked into the
   style wrapper every image prompt starts with.
5. **Recurring character.** Yes/no. If yes: describe them + define CONTEXT BOUNDARIES
   (e.g. "appears only in historical scenes, never in scenes addressing the modern
   viewer"). A master reference is generated in their provider during Step 5 of the
   install; its URL/passport goes into the profile.
6. **Image provider.** Midjourney (default) / Leonardo / GPT / other. "Other" → Claude
   researches its syntax and extends the image-prompts skill (that's a feature, not
   a problem). No subscription yet → suggest Midjourney, mention switching is one
   phrase later.
7. **Motion.** Animate scenes? Which service (Veo / Runway / other)? Scope:
   `hook` (recommended — first-minute retention is where channels die) / `full` /
   `none`. → `motion_scope`.
8. **Voiceover.** Which service do you use (any site/bot works)? Which voice?
   Claude only ever hands you text blocks + filenames; no API needed.
9. **Edit path.** DaVinci Resolve Studio installed? → A (Claude drives Resolve via
   MCP; offer setup/davinci-mcp-install.md). No → B (ready FCPXML timeline into any
   editor, free DaVinci included).
10. **Workspace location.** Default `~/my-channel/`, or inside their existing projects
    structure — their choice. (One purchase = any number of channels: a second
    workspace is just a second folder.)
11. **Pace.** Hours per week honestly available → Claude proposes a realistic
    production rhythm (e.g. 5 h/wk ≈ 1 long-form per 2 weeks + shorts). Write it
    down as the schedule baseline — ambition inflation kills channels quietly.

## channel-profile.md fields to fill

`niche, language, video_length_target, cadence, visual_style_wrapper, character
(+context_rules +reference), image_provider, motion_provider, motion_scope,
voice_service (+voice name), edit_path, workspace_path, weekly_hours, schedule,
channel_url (added after the channel exists), signature_hashtag`.

Unanswered field = write `TBD`, never invent. TBD fields block only the steps that
need them (e.g. publish-package needs `channel_url`).
