# Install mechanics — for Claude

> START.md gives the sequence; this file gives the exact mechanics for the
> destructive-adjacent parts. These rules are absolute.

## Backup & diff protocol (any edit to an EXISTING file)

1. Copy the file to `<name>.backup-YYYY-MM-DD` in the same directory.
2. Show the user the exact diff (before/after) of what you intend to change.
3. Apply only after an explicit "yes". "Probably fine" is not a yes.
4. Record in INSTALL-LOG.md: file, backup path, what changed, how to revert.

Applies to: MCP config files, the optional global CLAUDE.md pointer, shell profiles
(if the user asks for PATH changes) — and anything else that existed before.

## Skills installation

For each file in `<product>/skills/`:
1. Target: `~/.claude/skills/channelforge-<name>/SKILL.md`.
2. If the target directory already exists: STOP, tell the user, ask — overwrite
   (their own older copy) or skip. Never overwrite silently.
3. Log each installed skill in INSTALL-LOG.md.

## INSTALL-LOG.md format (human-readable, in the workspace)

```markdown
# ChannelForge install log — YYYY-MM-DD
| # | Action | Path | Undo |
|---|--------|------|------|
| 1 | Moved product folder | ~/Documents/ChannelForge | move back / delete |
| 2 | Installed skill | ~/.claude/skills/channelforge-script-writer/ | delete folder |
| 3 | Appended pointer (3 lines) | ~/.claude/CLAUDE.md (backup: .backup-YYYY-MM-DD) | delete marked block |
| 4 | Edited MCP config | <path> (backup: <path>.backup-YYYY-MM-DD) | restore backup |
```

No secrets, no API keys, no personal data in the log — paths and actions only.

## UNINSTALL.md — generate at the END of every install

A complete, ordered removal script in prose, matching what was ACTUALLY installed
(read INSTALL-LOG.md, don't guess). Template:

```markdown
# Uninstall ChannelForge
Say "uninstall ChannelForge" and Claude will execute this list,
asking before every deletion.

1. Delete skills: ~/.claude/skills/channelforge-* (list the actual ones)
2. Remove the pointer block between <!-- channelforge:start --> and
   <!-- channelforge:end --> in ~/.claude/CLAUDE.md (if it was added)
3. Restore MCP config from <backup> (if it was edited)
4. Delete the product folder: <path>
5. The workspace <path> contains YOUR videos and profile — Claude asks
   separately whether to delete or keep it.
Result: no trace of ChannelForge; none of your own files touched.
```

## Uninstall execution rules

- Confirm EVERY deletion individually; the workspace question is asked LAST and
  separately ("it contains your videos — delete or keep?").
- Only remove what INSTALL-LOG.md lists. Never "clean up" anything else.
- Backups created during install (`*.backup-YYYY-MM-DD`) are NOT deleted at
  uninstall — leave them for the user and mention where they are. They're the
  proof of what the original looked like.
- After finishing: show a summary of what was removed and what was kept.
