# DaVinci Resolve MCP — install guide (edit path A)

> For Claude to execute with the user. Path A is an ADVANCED OPTION on top of a
> fully working path B — if anything here fails, switch to B without drama:
> "Path B it is for now — your video still gets made. We can retry A anytime."

## Pre-checks (run before installing anything)

1. **Resolve is the STUDIO edition** — check `fusionscript.so` exists:
   `/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion/fusionscript.so`
   Missing → the free edition is installed; scripting is a Studio feature → path B.
2. **External scripting enabled** in Resolve: Preferences → System → General →
   "External scripting using" = **Local**. Ask the user to set it (screenshot-level
   guidance: DaVinci Resolve menu → Preferences → System tab → General).
3. **python 3.11** available (`python3.11 --version`) — Resolve's scripting API is
   picky about versions. Missing → `brew install python@3.11` (with approval).

## Install the MCP server

Use the open-source **lordhoell / davinci-resolve-mcp** project (battle-tested by
the authors of this pipeline; other Resolve MCP servers exist but this is the one
this product's scripts were built against).

1. Web-search "lordhoell davinci resolve mcp github" for the current repo and its
   README — install per THEIR current instructions (don't trust cached memory;
   the project may have changed).
2. Clone into the product folder's neighborhood or the user's preferred tools dir.
3. Add the server to the Claude Code MCP config — **backup + diff + explicit yes**
   (rules in 02-INSTALL.md). Typical env vars the server needs:
   `RESOLVE_SCRIPT_API=/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting`
   `RESOLVE_SCRIPT_LIB=/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion/fusionscript.so`
4. Restart Claude Code so the MCP loads.

## Smoke test (mandatory — "installed" ≠ "working")

1. Ask the user to LAUNCH Resolve (the API talks to a running instance).
2. Via MCP: create a project named `ChannelForge-test`, confirm it appears in
   Resolve's project manager, then delete it.
3. Both worked → path A is live; write `edit_path: A` + MCP details into
   channel-profile.md and INSTALL-LOG.md.
4. Anything failed → see troubleshooting below, and if it holds for more than
   ~10 minutes, offer path B and move on. Never leave the user stuck at setup.

## Troubleshooting quick hits

| Symptom | Likely cause |
|---|---|
| "Can't connect" | Resolve not running / external scripting not set to Local |
| Import error on fusionscript | free edition (no scripting) or wrong python version |
| MCP not listed in Claude | config typo or Claude Code not restarted |
| Works in terminal, not via MCP | env vars missing in the MCP config entry |

Assembly itself is `scripts/assemble-davinci.py` (run under python3.11) — see
`pipeline/phase-5-edit.md`. Zoom moves stay manual by design.
