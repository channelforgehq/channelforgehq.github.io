# <CHANNEL NAME> — workspace rules (local CLAUDE.md)

> This file lives in the channel workspace and applies ONLY here — the user's other
> projects are untouched. Installed by ChannelForge setup.

## Entry point

This workspace runs on the ChannelForge pipeline. Product folder: `<PRODUCT_PATH>`.

At the start of any video-work session:
1. Read `channel-profile.md` (this folder) — the single source of truth for the channel.
2. Read `<PRODUCT_PATH>/pipeline/PIPELINE.md` — the map, Rule Zero and the
   No-Guessing Protocol (binding).
3. Read ONLY the phase file for the current step. Not the whole product.

## Iron rules (duplicated from PIPELINE.md because they get broken otherwise)

- Steps strictly in order; one step at a time → show → wait for approval → next.
- The thumbnail BRIEF comes before the script. Always.
- Where a step names a `channelforge-*` skill — invoke it first. "From memory" = not done.
- Before generating ANY prompt: read `channel-profile.md`, use the provider set there.
- No number, status or filename from memory — files, script outputs and skills only.
- Anything involving platform rules (YouTube policies) — verify with a current web
  search, not from memory.

## Phrase router

"find me a niche" → Phase 1 · "video N: concept/script/production/edit/publish" →
Phases 2–6 · "video N: shorts" → shorts selection · "status" → status-tracker.md ·
"uninstall ChannelForge" → execute UNINSTALL.md.

## Model economy tip

Creative phases (1–3, 6) benefit from the strongest model; mechanics (4–5) run fine
on a cheaper one. Remind the user when a phase switch makes a model switch worthwhile.
