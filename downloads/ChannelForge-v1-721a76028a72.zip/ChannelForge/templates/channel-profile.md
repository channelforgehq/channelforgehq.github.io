# Channel profile — <CHANNEL NAME>

> The single source of truth for THIS channel. Every pipeline step reads this file
> before doing anything. Filled by the customization interview; edit anytime by
> asking Claude ("change my image provider to X").

| Field | Value |
|---|---|
| niche | TBD |
| language | en |
| video_length_target | ~9 min (≈1250–1300 spoken words) |
| cadence | TBD (e.g. 1 long-form / 2 weeks + 2 shorts each) |
| visual_style_wrapper | flat 2D cartoon style, clean bold outlines, soft cel shading, warm friendly tone |
| character | TBD (none / description) |
| character_context_rules | TBD (when the character may and may NOT appear) |
| character_reference | TBD (master image URL or text passport, per provider) |
| image_provider | TBD (midjourney / leonardo / gpt / other) |
| motion_provider | TBD (veo / runway / other / none) |
| motion_scope | hook (hook / full / none) |
| voice_service | TBD (any site or bot — no API needed) |
| voice_name | TBD |
| edit_path | TBD (A = DaVinci Studio via MCP / B = FCPXML into any editor) |
| workspace_path | TBD |
| weekly_hours | TBD |
| schedule | TBD (publish day/time in the audience's timezone) |
| channel_url | TBD (fill after the channel exists) |
| signature_hashtag | TBD |

## Notes
- TBD = not decided yet; it blocks only the steps that need it. Never guess a TBD.
- Changing a field mid-project is fine — prompts and packages adapt from the next step.
