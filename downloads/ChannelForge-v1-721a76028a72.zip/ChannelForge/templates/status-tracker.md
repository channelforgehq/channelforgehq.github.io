# Status tracker — <CHANNEL NAME>

> One row per video. Claude updates this file at every phase transition and reads
> it on "status". Analytics lessons land in the last column — next video starts
> by reading them.

## Videos

| # | Topic | Status | Published | 48h lesson |
|---|---|---|---|---|
| 01 | TBD | concept | — | — |

**Statuses:** `concept → script → assets → edit → publish → done` (+ `halted` by the stop-valve)

## Stop-valve state

2 long-forms in a row under 100 views in their first 7 days → production HALTS
(see phase-6). Current state: **inactive** (fewer than 2 published videos).

## Shorts log

| Video | Short | Scenes | Published | Views @7d |
|---|---|---|---|---|

## Corrections backlog (from 48h analytics — ONE change per video)

- (empty)
