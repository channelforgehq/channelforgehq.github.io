# Phase gate checklists

> Claude runs the matching checklist BEFORE showing the user any phase result.
> A failed line = fix first, then show. The user sees finals, not drafts.

## Phase 2 exit (concept)
- [ ] Topic passed: demand proven, monopolization filter, exact-dupe block, premise fact-check
- [ ] Title uses an approved construction; different construction than the previous 1–2 videos
- [ ] Thumbnail BRIEF approved BEFORE the script; palette written into the video project file
- [ ] Thumbnail and title split information (no duplication)

## Phase 3 exit (script)
- [ ] Retention checklist 7/7 (hook, loops, re-hook, but/therefore, 3× "wait WHAT", no dead sentences)
- [ ] Anti-slop pass done
- [ ] Numbers/statistics live in the voice; every beat maps to ONE image
- [ ] Character context marked per scene (if the channel has a character)
- [ ] Voice file: blocks, TTS-safe formatting (no em-dashes, numbers as words)

## Phase 4 exit (assets)
- [ ] ALL prompts written via the image-prompts skill, for the provider in channel-profile.md
- [ ] Prompt file named with the provider (prompts-NN-<provider>.md)
- [ ] Hook scenes use the thumbnail palette
- [ ] Motion prompts present per motion_scope; light movement only
- [ ] Scene-colored backgrounds everywhere (no white voids)
- [ ] rename-assets done; control sheet green; sync-map built without misses

## Phase 5 exit (edit)
- [ ] Assembly done (A: drift ≤0.3 s avg reported / B: FCPXML imported by the user)
- [ ] ⛔ FIRST-MINUTE TEST passed as a viewer (a "would swipe" = hook rebuilt, no publish)
- [ ] Final thumbnail generated per the 2.4 brief; readable at phone size
- [ ] 2 shorts moments picked by Claude + SRT files generated

## Phase 6 exit (publish)
- [ ] Metadata package passed the publish-package self-check (11 lines)
- [ ] ⛔ CROSS-CHECK read aloud: file ↔ title ↔ description ↔ tags ↔ thumbnail = ONE video
- [ ] Synthetic-content disclosure = YES (video AND shorts)
- [ ] Scheduled per channel profile; end screen + card + pinned comment planned
- [ ] Shorts: letterbox 9:16, cadence planned, descriptions neutral
- [ ] 48h analytics reminder set; stop-valve state updated in status-tracker
