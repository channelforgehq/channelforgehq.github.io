# Video folder layout

Create one folder per video: `videos/NN-topic/` (e.g. `videos/01-lost-cities/`).
Claude creates it at Phase 2 start from this template.

```
videos/NN-topic/
├── project.md                  ← topic, title, thumbnail brief + palette (Phase 2)
├── script-NN-DATE.md           ← the script table (Phase 3)
├── voice-NN-DATE.md            ← TTS-ready text blocks (Phase 3)
├── prompts-NN-<provider>.md    ← image + motion prompts (Phase 4)
├── voice/                      ← 1.mp3 … 6.mp3 from your TTS service
├── images/                     ← 001x.png … (renamed by the script)
│   └── motion/                 ← 001.mp4 … (image-to-video clips, if any)
├── music.mp3                   ← optional background track (any of .mp3/.wav/.m4a)
├── _assembly/                  ← generated: voice.wav, sync-map.json, bg.png
├── timestamps.json             ← generated: word-level transcript
├── control-sheet.html          ← generated: visual asset check
├── video.mp4                   ← the render
├── thumbnail.png               ← final thumbnail (Phase 5)
├── short-1-subs.srt            ← shorts subtitles (Phase 5)
└── timeline-*.fcpxml           ← path B timeline file
```

Rule: heavy files (mp4, images, mp3) of PUBLISHED videos can be cleaned to save
disk — keep the .md files, timestamps.json and the fcpxml; they're the record.
