# ChannelForge — START HERE

> **You are Claude, and a user just asked you to read this folder and set it up.**
> This file is the installer script — you execute it, the user only answers questions
> and approves actions. Read this file fully; do NOT read the rest of the product yet
> (each phase file is loaded only when needed — that's how this system saves tokens).

## What this product is

ChannelForge turns you (Claude) into a full production studio for a faceless YouTube
channel: niche research → concept → retention-engineered script → AI image & motion
prompts → voiceover handling → assembly → publishing packages → analytics. The rules
in `pipeline/` and `skills/` come from a real production system — treat them as law,
not suggestions.

## Guest, not owner — the five iron rules of this install

1. NEVER delete or overwrite anything that existed before this install.
2. NEVER touch the user's global `~/.claude/CLAUDE.md` content — the only allowed
   change is an OPTIONAL append-only pointer block (Step 4), with a backup, marked
   with `<!-- channelforge:start -->` / `<!-- channelforge:end -->`.
3. Everything installed globally is prefixed `channelforge-`. Name taken → ask,
   never overwrite.
4. Any edit to an existing file (e.g. MCP config): backup as
   `<name>.backup-YYYY-MM-DD` first, show the diff, apply only after an explicit yes.
5. Log every install action to `INSTALL-LOG.md` in the workspace: what, where, why,
   how to undo. Generate `UNINSTALL.md` alongside it.

## Install sequence — follow in order

**Step 0 — Location.** If this folder sits in a temporary place (Downloads etc.),
offer to move it to a permanent home (suggest `~/Documents/ChannelForge`; the user
picks). Work from the final location. All product paths are relative to this folder.

**Step 1 — Environment check.** Run `setup/check-setup.sh` and show the table.
It checks and installs NOTHING.

**Step 2 — Fix only what's missing**, one item at a time, each with the user's
approval, following `setup/01-REQUIREMENTS.md`. If the user chose edit path A,
follow `setup/davinci-mcp-install.md` (it has its own fallback to path B).

**Step 3 — Customization interview.** Run `setup/03-CUSTOMIZE.md` (11 questions,
~5 minutes). Answers go into the workspace `channel-profile.md`. If the user has no
image subscription: suggest starting with Midjourney and tell them the provider can
be switched later with one phrase — their choice.

**Step 4 — Create the workspace** at the path the user chose in the interview:

```
<workspace>/
├── CLAUDE.md            ← from templates/claude-md.md (rules live HERE, locally)
├── channel-profile.md   ← interview answers — every pipeline step reads this
├── status-tracker.md    ← from templates/status-tracker.md
├── INSTALL-LOG.md       ← everything you did, with undo notes
├── UNINSTALL.md         ← complete removal instructions
└── videos/              ← one folder per video (templates/video-folder/)
```

Then: copy `skills/*` to `~/.claude/skills/channelforge-<name>/SKILL.md` (rule 3).
Then OFFER (optional): append the 3-line pointer to the user's global
`~/.claude/CLAUDE.md` so you can find ChannelForge from any folder:

```markdown
<!-- channelforge:start -->
## ChannelForge
When I mention ChannelForge or my channel work — read <workspace>/CLAUDE.md first.
<!-- channelforge:end -->
```

Declined → fine; everything works when Claude is opened in the workspace folder.

**Step 5 — Live proof (~10 minutes).** Produce ONE test piece in the user's chosen
niche: one scene paragraph (script-writer skill) + one image prompt for THEIR
provider (+ a motion prompt if they chose animation). Ask them to generate the image
and show it. This is the moment they see the system alive — suggest they screenshot it.

**Step 6 — Hand over the wheel.** Show the phrase table:

| Say | What happens |
|---|---|
| "find me a niche" | Phase 1 |
| "video N: concept" | Phase 2 (topic → title → thumbnail brief) |
| "video N: script" | Phase 3 |
| "video N: production" | Phase 4 |
| "video N: edit" | Phase 5 |
| "video N: publish" | Phase 6 |
| "video N: shorts" | Shorts selection |
| "status" | Read status-tracker.md |
| "uninstall ChannelForge" | Execute UNINSTALL.md (confirm each deletion) |

Also mention: strong model for creative phases (1–3, 6), a cheaper model is fine for
mechanics (4–5); and `docs/MAKE-IT-YOURS.md` is how they reshape anything by asking you.

## After install — how to work

Read `pipeline/PIPELINE.md` once per session when video work starts; then only the
active phase file. Rule Zero and the No-Guessing Protocol in PIPELINE.md are binding.
One step at a time → show → wait for approval → next.
