# FAQ

**Do I need to know how to code?**
No. Claude runs every script; you answer questions, generate images/voice in your
own services, and approve steps.

**What exactly do I need to buy besides this?**
A Claude subscription that includes Claude Code, plus whatever image/voice services
you already use (any work — the pipeline adapts to yours). Full list:
`setup/01-REQUIREMENTS.md`. Your tools, your budget.

**Does it work on Windows?**
Not in v1 — built and tested on macOS only. We'd rather say no than sell you a maybe.

**Will my existing Claude setup break?**
No — that's a design pillar. Nothing of yours is modified or deleted; everything we
add is prefixed and logged (INSTALL-LOG.md), any config edit is backed up and shown
as a diff first, and `uninstall ChannelForge` removes every trace while keeping all
your files. Clean install, clean uninstall.

**Do I need DaVinci Resolve Studio?**
Only for the automated edit path (A). Path B generates a ready timeline file —
every image, the voiceover and music already on the tracks — that opens in the FREE
DaVinci Resolve, Final Cut or Premiere.

**Does it guarantee views or income?**
No, and run from anyone who guarantees that. This is a production system: it
guarantees a disciplined process — retention-engineered scripts, quality gates, an
honest analytics loop. The audience decides the rest.

**Can I run multiple channels?**
Yes — one purchase, any number of workspaces. Each has its own profile, niche and style.

**My channel isn't in English — supported?**
Yes. Scripts are written by Claude in your language; transcription takes a language
flag; all the retention math is language-independent.

**What about updates?**
There's no update subscription — deliberately. The product is plain text your Claude
rebuilds for you: see `docs/MAKE-IT-YOURS.md`. You own it, you evolve it.

**AI content policy — is this allowed on YouTube?**
The pipeline marks every upload with the synthetic-content disclosure and never
verifies policy "from memory" — Phase 6 includes checking current YouTube rules by
live search at publish time. Platform rules change; the system assumes that.

**Where do my API keys go?**
Nowhere — the default pipeline doesn't use any. You generate images and voice in
your own services by hand; Claude prepares exact prompts and filenames.
