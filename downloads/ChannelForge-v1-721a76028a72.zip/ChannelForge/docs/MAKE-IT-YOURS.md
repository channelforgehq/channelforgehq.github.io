# Make it yours

> ChannelForge ships once, in final form — no update subscription, no waiting for
> patches. That's deliberate: the whole system is plain text your Claude can rebuild
> for you. You own it. This file shows how.

## The one idea

Every rule, formula, checklist and script in this product is a file Claude can read
and rewrite. Changing the system = asking Claude in plain words. No code skills needed.

## Recipes (say it roughly like this)

**Switch image provider**
> "Switch my image provider to Ideogram — research its prompt syntax, test one scene
> with me, and add an adapter to the image-prompts skill."

**Change what gets animated**
> "Set motion_scope to full — I want every scene animated from now on."

**Retarget the format**
> "Rebuild the pipeline for 20-minute deep-dives: adjust the word target, block
> count and re-hook spacing in phase-3 and the script-writer skill."

**Add a platform**
> "Add a TikTok export step to phase 6: 9:16 letterbox, max 60 s, its own
> description rules in the publish-package skill."

**New niche, second channel**
> "Create a second workspace for a finance channel — run the customization
> interview again." (One purchase = any number of channels.)

**Rewrite a formula that doesn't fit your niche**
> "The title constructions feel wrong for kids' content — rewrite the formulas
> section of hooks-and-titles for a parent audience."

**Localize everything**
> "My channel is in Spanish — set the profile language and make sure transcription
> (whisper language flag) and all public text rules follow it."

## Two safety habits

1. **Copy before big surgery:** "duplicate the skills folder as skills-backup first".
   It's plain files — your undo is a folder copy.
2. **Test on one video:** after a big rework, run one video through before trusting
   the change. The first-minute test and phase checklists still apply — keep them.
   They're the part that keeps quality up when everything else changes.

## What NOT to remove

You can change anything, but these three guardrails have scars behind them:
the **first-minute test** (5.1), the **pre-publish cross-check** (6.2), and the
**stop-valve** (6.6). Remove them and the system will still run — right into the
walls they exist to prevent.
