# Troubleshooting

> First move for ANY problem: tell Claude what happened and show the error —
> it can read every script and fix most issues in place. This file covers the
> known sharp edges.

## Setup

| Problem | Fix |
|---|---|
| `check-setup.sh` says ffmpeg missing | `brew install ffmpeg` (Claude offers this) |
| `pip3 install faster-whisper` fails | try `python3 -m pip install faster-whisper`; on old pythons install a newer python3 via brew |
| Skill name already exists at install | you probably installed before — let Claude compare and decide with you |
| Claude "forgets" ChannelForge in other folders | you declined the global pointer — either work from the workspace folder, or say "add the ChannelForge pointer to my global CLAUDE.md" |

## DaVinci MCP (path A)

See the table in `setup/davinci-mcp-install.md`. Golden rule: Resolve must be
RUNNING, edition must be STUDIO, scripting = Local, python = 3.11. Ten minutes of
failure → switch to path B, make the video, retry A later.

## Assets (Phase 4)

| Problem | Fix |
|---|---|
| Images landed in wrong scenes | you downloaded out of order — rename-assets sorts by file time. Ask Claude to fix the specific swaps (rename files in `images/`), regenerate control sheet |
| webp→png conversion failed | macOS `sips` is used; check the file isn't corrupted, or convert via ffmpeg |
| sync-map reports missing anchors | the voiced text differs from the script table (you edited while recording?) — update the table to match reality, rerun |
| Whisper transcribes badly | non-English channel? pass the language: `transcribe-audio.py <folder> es` |

## Edit (Phase 5)

| Problem | Fix |
|---|---|
| FCPXML import shows offline media | the .fcpxml references absolute paths — don't move the video folder between generating and importing; regenerate after moves |
| Scene visibly off its phrase | drag it in the editor (that's why path B exists); if MANY drift, the voice files were re-recorded after transcription — rerun transcribe + sync-map |
| Scenes under 1.5 s look twitchy | merge them with a neighbor in the editor, or ask Claude to merge those scene beats in the script next time |
| Music too loud/quiet | it's one clip level (−20 dB default) — adjust in the editor, or ask Claude to change the default in the script |

## Shorts

| Problem | Fix |
|---|---|
| `letterbox-916.sh` exits with "no subtitles filter" | your ffmpeg lacks libass (common with homebrew). Say: "burn the SRT into this short via PIL PNG overlays" — Claude writes a small 2-pass script (PIL renders each cue to a transparent PNG, ffmpeg overlays with `between(t,t0,t1)`). This is a known, solved path. |
| Short looks zoom-cropped | someone used scale+crop — always letterbox (`scale=1080:-2,pad`), rerun the script |

## Quality (the honest section)

| Problem | Fix |
|---|---|
| "The output looks like AI slop" | check the gates were actually run: style wrapper on every prompt? colored backgrounds? retention checklist 7/7? The gates only work when they're not skipped |
| Views are low | that's not a malfunction — it's the game. Follow phase-6: 48h funnel diagnosis, ONE change per video, stop-valve after 2 flops. The system manages the process; the audience decides the outcome |
