# License — personal use

Copyright (c) 2026 ChannelForge. All rights reserved.

**You may:**
- Use ChannelForge for any number of your own YouTube channels and projects,
  personal or commercial (the videos you make are entirely yours).
- Modify, extend and rebuild any part of it for your own use.
- Keep copies on your own devices and in your own private backups.

**You may not:**
- Resell, redistribute, publish or share the product files (original or modified),
  in whole or in substantial part, free or paid.
- Repackage it as your own product, template, course material or public repository.

One purchase = one person. If a friend wants it, send them to the store page —
that's what keeps this product maintained and honest.

THE PRODUCT IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. NO GUARANTEE OF
VIEWS, REVENUE OR PLATFORM OUTCOMES IS MADE OR IMPLIED. YOU ARE RESPONSIBLE FOR
COMPLYING WITH THE TERMS OF THE PLATFORMS AND SERVICES YOU USE (YouTube, image,
voice and editing tools).
