#!/usr/bin/env python3
"""
Path B assembly: generates a TIMELINE PROJECT FILE (FCPXML) with everything
already in place — every scene image (or motion clip) at its exact frame,
the voiceover on audio lane 1, looped music at −20 dB with a fade-out on
lane 2. Open it in the free DaVinci Resolve (File → Import Timeline → XML),
Final Cut or Premiere — and fix anything by hand if a scene drifted.

Nothing is rendered here on purpose: the edit stays editable.

Usage: python3 scripts/generate-fcpxml.py <video-folder> [--res 3840x2160] [--fps 24]
Requires: _assembly/sync-map.json + _assembly/voice.wav (+ optional music.*)
"""

import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import date
from pathlib import Path

import json

sys.path.insert(0, str(Path(__file__).parent))
from video_project import video_dir_from_argv

BASE = video_dir_from_argv()
RES, FPS = "3840x2160", 24
if "--res" in sys.argv:
    RES = sys.argv[sys.argv.index("--res") + 1]
if "--fps" in sys.argv:
    FPS = int(sys.argv[sys.argv.index("--fps") + 1])
W, H = map(int, RES.split("x"))
TB = FPS * 1000  # FCPXML timebase

MUSIC_VOLUME = "-20dB"
MUSIC_FADEOUT = 3.0

ASSEMBLY = BASE / "_assembly"
sync_file = ASSEMBLY / "sync-map.json"
if not sync_file.exists():
    sys.exit("sync-map.json not found — run build-sync-map.py first")
SCENES = json.loads(sync_file.read_text(encoding="utf-8"))["scenes"]
VOICE = ASSEMBLY / "voice.wav"
if not VOICE.exists():
    sys.exit("_assembly/voice.wav not found — run transcribe-audio.py first")


def probe_duration(p: Path) -> float:
    return float(subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(p)], capture_output=True, text=True).stdout.strip())


def to_time(seconds: float) -> str:
    frames = int(round(seconds * FPS))
    return f"{frames * (TB // FPS)}/{TB}s"


voice_dur = probe_duration(VOICE)
total_dur = max(voice_dur, SCENES[-1]["start"] + SCENES[-1]["duration"]) + 0.5

# background slate (solid dark) — the base clip everything connects to;
# visible only if a gap opens between scenes
bg = ASSEMBLY / "bg.png"
if not bg.exists():
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", f"color=c=0x101010:s={W}x{H}",
                    "-frames:v", "1", str(bg)], check=True)

music_src = next((p for p in BASE.glob("music.*") if p.suffix in (".mp3", ".wav", ".m4a")), None)

# ── build XML ────────────────────────────────────────────────────────────────
root = ET.Element("fcpxml", version="1.9")
res = ET.SubElement(root, "resources")
ET.SubElement(res, "format", id="r0", name=f"FFVideoFormat{W}x{H}p{FPS}",
              frameDuration=f"{TB // FPS}/{TB}s", width=str(W), height=str(H),
              colorSpace="1-1-1 (Rec. 709)")

asset_ids, next_id = {}, 1
def add_asset(path: Path, video: bool, audio: bool, dur: float | None = None) -> str:
    global next_id
    key = str(path)
    if key in asset_ids:
        return asset_ids[key]
    aid = f"r{next_id}"; next_id += 1
    attrs = dict(id=aid, name=path.stem, src=f"file://{path.resolve()}",
                 hasVideo="1" if video else "0", hasAudio="1" if audio else "0")
    if video:
        attrs["format"] = "r0"
    if dur is not None:
        attrs["duration"] = to_time(dur)
    if audio:
        attrs.update(audioSources="1", audioChannels="2")
    ET.SubElement(res, "asset", **attrs)
    asset_ids[key] = aid
    return aid

bg_id = add_asset(bg, video=True, audio=False)
voice_id = add_asset(VOICE, video=False, audio=True, dur=voice_dur)
music_id = music_dur = None
if music_src:
    music_dur = probe_duration(music_src)
    music_id = add_asset(music_src, video=False, audio=True, dur=music_dur)
for s in SCENES:
    src = BASE / (s.get("motion") or s["path"])
    is_motion = bool(s.get("motion"))
    add_asset(src, video=True, audio=False,
              dur=probe_duration(src) if is_motion else None)

library = ET.SubElement(root, "library")
event = ET.SubElement(library, "event", name="ChannelForge")
project = ET.SubElement(event, "project", name=BASE.name)
sequence = ET.SubElement(project, "sequence", duration=to_time(total_dur),
                         format="r0", tcStart="0s", tcFormat="NDF",
                         audioLayout="stereo", audioRate="44100")
spine = ET.SubElement(sequence, "spine")

# base slate on the primary storyline
bg_elem = ET.SubElement(spine, "video", ref=bg_id, offset="0s",
                        duration=to_time(total_dur), start="0s")

# scenes as connected clips on lane 1; offsets/durations in frames so
# neighbours never overlap from independent rounding
short_clips = []
for i, s in enumerate(SCENES):
    start = 0.0 if i == 0 else s["start"]
    end = (SCENES[i + 1]["start"] if i + 1 < len(SCENES)
           else max(voice_dur, s["start"] + s["duration"]))
    off_f = int(round(start * FPS))
    dur_f = max(int(round(end * FPS)) - off_f, 1)
    src = BASE / (s.get("motion") or s["path"])
    ET.SubElement(bg_elem, "video", ref=asset_ids[str(src)], lane="1",
                  offset=f"{off_f * (TB // FPS)}/{TB}s",
                  duration=f"{dur_f * (TB // FPS)}/{TB}s", start="0s")
    if dur_f / FPS < 1.5:
        short_clips.append((s["scene"], round(dur_f / FPS, 2)))

# voice on lane -1 (single file, global timecodes)
ET.SubElement(bg_elem, "audio", ref=voice_id, lane="-1", offset="0s",
              duration=to_time(voice_dur), role="dialogue")

# music on lane -2: tiled to full length, −20 dB, fade-out on the last piece
if music_id:
    pos, loops = 0.0, 0
    while pos < total_dur - 0.01:
        piece = min(music_dur, total_dur - pos)
        is_last = (pos + piece) >= total_dur - 0.01
        mus = ET.SubElement(bg_elem, "audio", ref=music_id, lane="-2",
                            offset=to_time(pos), duration=to_time(piece),
                            start="0s", role="music")
        vol = ET.SubElement(mus, "adjust-volume", amount=MUSIC_VOLUME)
        if is_last and piece > MUSIC_FADEOUT:
            param = ET.SubElement(vol, "param", name="amount")
            anim = ET.SubElement(param, "keyframeAnimation")
            ET.SubElement(anim, "keyframe", time=to_time(piece - MUSIC_FADEOUT),
                          value=MUSIC_VOLUME, interp="linear")
            ET.SubElement(anim, "keyframe", time=to_time(piece),
                          value="-96dB", interp="linear")
        pos += piece
        loops += 1

out = BASE / f"timeline-{BASE.name}-{date.today():%Y-%m-%d}.fcpxml"
ET.ElementTree(root).write(out, encoding="utf-8", xml_declaration=True)

print(f"✓ {out.name}")
print(f"  Scenes: {len(SCENES)} · motion: {sum(1 for s in SCENES if s.get('motion'))}"
      f" · runtime ~{int(total_dur // 60)}:{int(total_dur % 60):02d} at {RES}@{FPS}")
print(f"  Voice: lane A1 · music: {'looped, -20dB, fade-out' if music_id else 'none found (music.* in the video folder)'}")
if short_clips:
    print(f"  ⚠ Scenes shorter than 1.5s — eyeball these after import: {short_clips}")
print("\nOpen in your editor: DaVinci Resolve (free) → File → Import Timeline →"
      " Import AAF, EDL, XML… — everything is on the tracks, adjust by hand as needed.")
