#!/usr/bin/env python3
"""
Renames downloaded scene images into pipeline scene numbers.

- Scene numbers come from the script table automatically.
- IMPORTANT: files are sorted by modification time — download images strictly
  in prompt order, or they'll land in the wrong scenes.
- webp files are converted to png (macOS `sips`).
- Output names use an `x` suffix (001x.png) so editors don't collapse them
  into an image sequence.
- Also cross-checks the voice text vs the script and runs the control sheet.

Usage: python3 scripts/rename-assets.py <video-folder> [downloads-folder]
       (downloads-folder defaults to ~/Downloads)
"""

import difflib
import os
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from video_project import parse_script, video_dir_from_argv

BASE = video_dir_from_argv()
SOURCE = Path(sys.argv[2]).expanduser() if len(sys.argv) > 2 else Path.home() / "Downloads"
TARGET_DIR = BASE / "images"


def extract_voice_text(base: Path) -> str:
    """All voiceover text from voice-*.md (contents of ``` code blocks)."""
    files = sorted(base.glob("voice-*.md"))
    if not files:
        return ""
    text = files[0].read_text(encoding="utf-8")
    blocks = re.findall(r"```\n(.*?)```", text, re.DOTALL)
    return " ".join(b.strip() for b in blocks)


def compare_voice_script(base: Path):
    """Word-level diff between the voice file and the script table."""
    voice = extract_voice_text(base)
    script = " ".join(s["text"] for s in parse_script(base) if s["text"])
    if not voice:
        print("⚠ Voice file not found — comparison skipped.")
        return

    def norm(t):
        return re.sub(r"[^a-z0-9\s]", "", t.lower()).split()

    v, s = norm(voice), norm(script)
    sm = difflib.SequenceMatcher(None, v, s, autojunk=False)
    extras = [
        " ".join(v[i1:i2])
        for tag, i1, i2, j1, j2 in sm.get_opcodes()
        if tag in ("replace", "delete") and i2 > i1
    ]
    extras = [p for p in extras if len(p.split()) >= 3]

    if not extras:
        print("✓ Voice and script match — no discrepancies.")
        return
    print("\n⚠ DISCREPANCIES — phrases in the voice but not in the script:")
    for p in extras:
        print(f"  — “{p}”")
    print("\nEither update the script table, or accept minor differences and continue.\n")
    if input("Continue renaming? (yes/no): ").strip().lower() not in ("y", "yes"):
        sys.exit("Cancelled. Fix the discrepancies and rerun.")


# ── collect downloads ────────────────────────────────────────────────────────
SCENE_NUMBERS = [s["num"] for s in parse_script(BASE)]
print(f"\nScenes in the script: {len(SCENE_NUMBERS)}")

if not SOURCE.is_dir():
    sys.exit(f"Downloads folder not found: {SOURCE}")

EXTS = (".png", ".jpg", ".jpeg", ".webp")
files = [f for f in os.listdir(SOURCE) if f.lower().endswith(EXTS) and not f.startswith(".")]
files.sort(key=lambda f: os.path.getmtime(SOURCE / f))
print(f"Images in downloads: {len(files)}")

if len(files) != len(SCENE_NUMBERS):
    print(f"⚠ Expected {len(SCENE_NUMBERS)}, found {len(files)}")
    if input("Continue anyway? (yes/no): ").strip().lower() not in ("y", "yes"):
        sys.exit(1)

print("\n── Comparing voice vs script ──")
compare_voice_script(BASE)

print("── Moving images ──")
TARGET_DIR.mkdir(exist_ok=True)
count = min(len(files), len(SCENE_NUMBERS))
for i in range(count):
    src = SOURCE / files[i]
    ext = src.suffix.lower()
    if ext == ".webp":
        dst = TARGET_DIR / f"{SCENE_NUMBERS[i]}x.png"
        subprocess.run(["sips", "-s", "format", "png", str(src), "--out", str(dst)],
                       capture_output=True)
        src.unlink()
    else:
        dst = TARGET_DIR / f"{SCENE_NUMBERS[i]}x{'.png' if ext == '.png' else '.jpg'}"
        src.rename(dst)
    print(f"  ✓ {files[i][:48]}  →  {dst.name}")

print(f"\nDone: {count} images moved to {TARGET_DIR}")
if len(files) < len(SCENE_NUMBERS):
    missing = SCENE_NUMBERS[len(files):]
    print(f"Still to generate: {len(missing)} images — scenes {missing}")

print("\n── Generating control sheet ──")
subprocess.run([sys.executable, str(Path(__file__).parent / "control-sheet.py"), str(BASE)])
