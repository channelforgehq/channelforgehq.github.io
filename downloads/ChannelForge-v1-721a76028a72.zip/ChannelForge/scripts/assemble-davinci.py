#!/usr/bin/env python3
# Path A assembly: builds the timeline inside DaVinci Resolve STUDIO.
# Run under python 3.11 (Resolve's scripting API requirement on most setups):
#
#   python3.11 scripts/assemble-davinci.py <video-folder> [--render]
#
# What it does:
#  1. Reads _assembly/sync-map.json.
#  2. Creates a project (fps/resolution from CLI or defaults 3840x2160@24).
#  3. Imports stills/motion clips one by one (the `x` filename suffix
#     prevents Resolve from collapsing them into an image sequence).
#  4. Places every scene exactly at its start_frame; voice on audio track 1,
#     looped music at −20 dB on track 2.
#  5. Zoom/Ken Burns is NOT baked — the user adds moves by hand afterwards.
#  6. --render: renders with the YouTube 2160p preset → video.mp4.
#
# Requires: DaVinci Resolve STUDIO running, external scripting enabled
# (Preferences → System → General → External scripting using: Local).

import json
import os
import subprocess
import sys
from pathlib import Path

os.environ.setdefault("RESOLVE_SCRIPT_API",
    "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting")
os.environ.setdefault("RESOLVE_SCRIPT_LIB",
    "/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion/fusionscript.so")
sys.path.append(os.environ["RESOLVE_SCRIPT_API"] + "/Modules")

sys.path.insert(0, str(Path(__file__).parent))
from video_project import video_dir_from_argv

BASE = video_dir_from_argv()
FPS = 24
W, H = 3840, 2160
STILL_DURATION = 9999  # max still length in frames — lets you drag edges later

sync_file = BASE / "_assembly" / "sync-map.json"
if not sync_file.exists():
    sys.exit("sync-map.json not found — run build-sync-map.py first")
DATA = json.loads(sync_file.read_text(encoding="utf-8"))
SCENES = DATA["scenes"]
FPS = DATA.get("fps", FPS)

voice = BASE / "_assembly" / "voice.wav"
if not voice.exists():
    sys.exit("_assembly/voice.wav not found — run transcribe-audio.py first")


def probe_duration(p: Path) -> float:
    return float(subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(p)], capture_output=True, text=True).stdout.strip())


# looped music at −20 dB, same length as the voice (optional)
music_loop = None
music_src = next((p for p in BASE.glob("music.*") if p.suffix in (".mp3", ".wav", ".m4a")), None)
if music_src:
    music_loop = BASE / "_assembly" / "music-loop.wav"
    if not music_loop.exists():
        dur = probe_duration(voice)
        print(f"Looping music to {dur:.1f}s at -20dB...")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                        "-stream_loop", "-1", "-i", str(music_src), "-t", str(dur),
                        "-af", "volume=-20dB", "-c:a", "pcm_s16le", str(music_loop)],
                       check=True)

# ── connect to Resolve ───────────────────────────────────────────────────────
try:
    import DaVinciResolveScript as dvr
    resolve = dvr.scriptapp("Resolve")
except Exception:
    resolve = None
if resolve is None:
    sys.exit("Can't connect to DaVinci Resolve.\n"
             "Check: Resolve STUDIO is running; Preferences → System → General →\n"
             "External scripting using = Local; running under python 3.11.\n"
             "Fallback: use Path B — scripts/assemble-ffmpeg.py")

pm = resolve.GetProjectManager()
proj_name = f"ChannelForge {BASE.name}"
p = pm.CreateProject(proj_name) or pm.LoadProject(proj_name)

for k, v in [("timelineFrameRate", str(FPS)),
             ("timelineResolutionWidth", str(W)),
             ("timelineResolutionHeight", str(H)),
             ("stillImageDuration", str(STILL_DURATION))]:
    p.SetSetting(k, v)

mp = p.GetMediaPool()
root = mp.GetRootFolder()
old = root.GetClipList() or []
if old:
    mp.DeleteClips(old)

print("Importing media...")
mp.ImportMedia([str(voice)])
if music_loop:
    mp.ImportMedia([str(music_loop)])
for s in SCENES:
    mp.ImportMedia([str(BASE / (s.get("motion") or s["path"]))])

by = {it.GetClipProperty("File Path"): it for it in (root.GetClipList() or [])}
expected = len(SCENES) + 1 + (1 if music_loop else 0)
print(f"Media pool: {len(by)} / {expected}")

total_frames = round(probe_duration(voice) * FPS)

clip_infos = []
for i, s in enumerate(SCENES):
    item = by.get(str(BASE / (s.get("motion") or s["path"])))
    if item is None:
        print(f"⚠ not in pool: scene {s['scene']}")
        continue
    if i + 1 < len(SCENES):
        display = SCENES[i + 1]["start_frame"] - s["start_frame"]
    else:
        display = total_frames - s["start_frame"]
    clip_infos.append({"mediaPoolItem": item, "startFrame": 0,
                       "endFrame": max(display, 1)})

for i in range(1, p.GetTimelineCount() + 1):
    t = p.GetTimelineByIndex(i)
    if t and t.GetName() == proj_name:
        mp.DeleteTimelines([t])
        break

print(f"Building timeline from {len(clip_infos)} clips...")
tl = mp.CreateTimelineFromClips(proj_name, clip_infos)
if not tl:
    sys.exit("✗ CreateTimelineFromClips returned None")
p.SetCurrentTimeline(tl)
tl.SetStartTimecode("00:00:00:00")
tl.AddTrack("audio")
ST = tl.GetStartFrame()

v = by.get(str(voice))
if v:
    mp.AppendToTimeline([{"mediaPoolItem": v, "mediaType": 2,
                          "trackIndex": 1, "recordFrame": ST}])
if music_loop and by.get(str(music_loop)):
    mp.AppendToTimeline([{"mediaPoolItem": by[str(music_loop)], "mediaType": 2,
                          "trackIndex": 2, "recordFrame": ST}])

pm.SaveProject()
print(f"✓ Timeline built: {len(clip_infos)}/{len(SCENES)} scenes. Project: {proj_name}")
print("  Add zoom moves by hand, then review (first-minute test!).")

# ── drift check: read real positions back, compare to the plan ───────────────
items = tl.GetItemListInTrack("video", 1) or []
drifts = []
for it, s in zip(items, SCENES):
    real = it.GetStart() - ST
    drifts.append(abs(real - s["start_frame"]) / FPS)
if drifts:
    avg = sum(drifts) / len(drifts)
    bad = [(SCENES[i]["scene"], round(d, 2)) for i, d in enumerate(drifts) if d > 0.3]
    print(f"  Drift check: avg {avg:.3f}s" + ("" if not bad else f" · scenes over 0.3s: {bad}"))

# ── optional render ──────────────────────────────────────────────────────────
if "--render" in sys.argv:
    print("Rendering (YouTube 2160p preset)...")
    p.LoadRenderPreset("YouTube - 2160p")
    p.SetRenderSettings({"TargetDir": str(BASE), "CustomName": "video"})
    p.AddRenderJob()
    p.StartRendering(isInteractiveMode=False)
    print("  Render job started — check Resolve's Deliver page.")
