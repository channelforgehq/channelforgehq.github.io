#!/usr/bin/env python3
"""
Shared helpers for ChannelForge scripts: locate the video folder,
parse the script table, list scenes.

The script table lives in the video folder as script-*.md with rows:
| # | Voiceover text | Scene image |
Scene numbers are zero-padded 3-digit strings ("001", "002", ...).
"""

import re
import sys
from pathlib import Path


def video_dir_from_argv() -> Path:
    """First CLI argument = path to the video folder (default: cwd)."""
    base = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else Path.cwd()
    if not base.is_dir():
        sys.exit(f"Video folder not found: {base}")
    return base


def find_script_file(base: Path) -> Path:
    candidates = sorted(base.glob("script-*.md"))
    if not candidates:
        sys.exit(f"No script-*.md found in {base}")
    return candidates[0]


def parse_script(base: Path) -> list[dict]:
    """Parse the script table into [{'num': '001', 'text': ..., 'image': ...}]."""
    text = find_script_file(base).read_text(encoding="utf-8")
    scenes = []
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 3:
            continue
        m = re.match(r"^(\d{1,3})$", cells[0])
        if not m:
            continue  # header/separator rows
        scenes.append({
            "num": f"{int(m.group(1)):03d}",
            "text": cells[1],
            "image": cells[2],
        })
    if not scenes:
        sys.exit("Script table parsed but no scene rows found — check the format: | # | text | image |")
    return scenes


def anchor_words(scene_text: str, n: int = 5) -> list[str]:
    """First N normalized words of a scene's voiceover — the sync anchor."""
    words = re.sub(r"[^a-z0-9\s]", "", scene_text.lower()).split()
    return words[:n]
