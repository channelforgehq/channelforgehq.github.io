#!/bin/bash
# Converts a horizontal cut into a 9:16 short via LETTERBOX — never zoom-crop
# (zoom-crop destroys the image composition; letterbox keeps the full frame).
#
# Usage: ./scripts/letterbox-916.sh input.mp4 output.mp4 [subs.srt]
# If an SRT is given, subtitles are burned in below the video area.

set -e
IN="$1"; OUT="$2"; SUBS="$3"

if [ -z "$IN" ] || [ -z "$OUT" ]; then
  echo "Usage: letterbox-916.sh input.mp4 output.mp4 [subs.srt]"; exit 1
fi

FILTER="scale=1080:-2,pad=1080:1920:0:(1920-ih)/2:black"

if [ -n "$SUBS" ]; then
  # NOTE: homebrew ffmpeg is often built WITHOUT libass — check first.
  if ffmpeg -hide_banner -filters 2>/dev/null | grep -q "subtitles"; then
    FILTER="$FILTER,subtitles='$SUBS':force_style='FontSize=14,Alignment=2,MarginV=60'"
  else
    echo "⚠ Your ffmpeg has no subtitles filter (no libass)."
    echo "  Ask Claude to burn subtitles via PIL PNG overlays instead"
    echo "  (see docs/TROUBLESHOOTING.md → 'Burning subtitles without libass')."
    exit 2
  fi
fi

ffmpeg -y -i "$IN" -vf "$FILTER" -c:v libx264 -preset fast -crf 18 \
  -pix_fmt yuv420p -c:a copy "$OUT"

echo "✓ $OUT (9:16 letterbox)"
