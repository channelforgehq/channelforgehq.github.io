#!/usr/bin/env python3
"""
Transcribes the video's voiceover as one file for word-accurate image syncing.

1. Concatenates voice/1.mp3…N.mp3 with 0.8 s gaps → _assembly/voice.wav
2. Whisper transcribes the whole file (global context = better phrase starts)
3. Output: timestamps.json {"words": [{word, start, end}, ...]} — global timecodes

Usage: python3 scripts/transcribe-audio.py <video-folder>
Deps:  ffmpeg, `pip3 install faster-whisper`
"""

import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from video_project import video_dir_from_argv

BASE = video_dir_from_argv()
AUDIO = BASE / "voice"
ASSEMBLY = BASE / "_assembly"
VOICE_WAV = ASSEMBLY / "voice.wav"
OUT = BASE / "timestamps.json"
INTER_BLOCK_GAP = 0.8

blocks = sorted(int(p.stem) for p in AUDIO.glob("*.mp3") if p.stem.isdigit())
if not blocks:
    sys.exit(f"No voice blocks in {AUDIO} (expected 1.mp3, 2.mp3, ...)")

ASSEMBLY.mkdir(exist_ok=True)

print(f"Concatenating {len(blocks)} blocks with {INTER_BLOCK_GAP}s gaps → {VOICE_WAV.name} ...", flush=True)
inp, filt, idx = [], [], 0
for bi, b in enumerate(blocks):
    inp += ["-i", str(AUDIO / f"{b}.mp3")]
    filt.append(f"[{idx}:a]")
    idx += 1
    if bi != len(blocks) - 1:
        inp += ["-f", "lavfi", "-t", str(INTER_BLOCK_GAP), "-i", "anullsrc=r=44100:cl=stereo"]
        filt.append(f"[{idx}:a]")
        idx += 1

r = subprocess.run(
    ["ffmpeg", "-y", "-loglevel", "error", *inp,
     "-filter_complex", "".join(filt) + f"concat=n={idx}:v=0:a=1[o]",
     "-map", "[o]", "-c:a", "pcm_s16le", str(VOICE_WAV)],
    capture_output=True, text=True,
)
if r.returncode != 0:
    sys.exit("FFMPEG ERROR: " + r.stderr[-400:])
print("  voice.wav ready", flush=True)

print("Transcribing (faster-whisper base, CPU)...", flush=True)
from faster_whisper import WhisperModel

# language comes from channel-profile via CLI flag if not English
lang = sys.argv[2] if len(sys.argv) > 2 else "en"
model = WhisperModel("base", device="cpu", compute_type="int8")
segments, _ = model.transcribe(str(VOICE_WAV), language=lang,
                               word_timestamps=True, vad_filter=False)

words = [
    {"word": w.word.strip(), "start": round(w.start, 3), "end": round(w.end, 3)}
    for seg in segments for w in (seg.words or [])
]
print(f"  → {len(words)} words", flush=True)

OUT.write_text(json.dumps({"words": words}, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\n✓ Saved: {OUT}")
