#!/usr/bin/env python3
"""
Control sheet: an HTML gallery of every scene — number, voiceover snippet,
the image found for it (or a red MISSING card). Claude inspects it after
rename-assets.py; the user only sees it when something is wrong.

Usage: python3 scripts/control-sheet.py <video-folder>
"""

import html
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from video_project import parse_script, video_dir_from_argv

BASE = video_dir_from_argv()
IMAGES = BASE / "images"
MOTION = IMAGES / "motion"
OUT = BASE / "control-sheet.html"

scenes = parse_script(BASE)
cards, missing = [], 0

for s in scenes:
    num = s["num"]
    img = next(iter(IMAGES.glob(f"{num}x.*")), None)
    clip = next(iter(MOTION.glob(f"{num}*.mp4")), None) if MOTION.is_dir() else None
    snippet = html.escape(s["text"][:110])
    if img:
        media = f'<img src="images/{img.name}" loading="lazy">'
        cls, badge = "ok", ("MOTION" if clip else "")
    else:
        media, cls, badge = "<div class='ph'>NO FILE</div>", "missing", "MISSING"
        missing += 1
    cards.append(
        f"<div class='card {cls}'><div class='head'>#{num} "
        f"<span class='badge'>{badge}</span></div>{media}<p>{snippet}</p></div>"
    )

OUT.write_text(f"""<!doctype html><meta charset="utf-8"><title>Control sheet</title>
<style>
body{{font-family:system-ui;background:#111;color:#eee;margin:20px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px}}
.card{{background:#1c1c1c;border-radius:10px;padding:10px;border:2px solid #2a2a2a}}
.card.missing{{border-color:#e33}}
.card img{{width:100%;border-radius:6px}}
.ph{{height:160px;display:flex;align-items:center;justify-content:center;background:#400;border-radius:6px}}
.head{{font-weight:600;margin-bottom:6px}}
.badge{{font-size:11px;color:#f90}}
p{{font-size:12px;color:#aaa}}
</style>
<h2>Scenes: {len(scenes)} · Missing: {missing}</h2>
<div class="grid">{''.join(cards)}</div>""", encoding="utf-8")

print(f"{'⚠' if missing else '✓'} Control sheet: {OUT}  (missing: {missing})")
sys.exit(1 if missing else 0)
