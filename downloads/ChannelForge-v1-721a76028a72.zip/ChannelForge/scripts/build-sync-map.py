#!/usr/bin/env python3
"""
Builds the scene→frame sync map: finds each scene's opening words (anchor)
in the Whisper transcript and records the exact start frame.

Input:  timestamps.json (from transcribe-audio.py) + the script table
Output: _assembly/sync-map.json
        [{"scene": "001", "path": "images/001x.png", "motion": null|path,
          "start": 12.34, "start_frame": 296, "duration": 4.2}, ...]

Usage: python3 scripts/build-sync-map.py <video-folder> [--fps 24]
"""

import difflib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from video_project import parse_script, anchor_words, video_dir_from_argv

BASE = video_dir_from_argv()
FPS = 24
if "--fps" in sys.argv:
    FPS = int(sys.argv[sys.argv.index("--fps") + 1])

ts_file = BASE / "timestamps.json"
if not ts_file.exists():
    sys.exit("timestamps.json not found — run transcribe-audio.py first")
WORDS = json.loads(ts_file.read_text(encoding="utf-8"))["words"]
norm_words = [re.sub(r"[^a-z0-9]", "", w["word"].lower()) for w in WORDS]

scenes = parse_script(BASE)
IMAGES = BASE / "images"
MOTION = IMAGES / "motion"

def find_anchor(anchor: list[str], search_from: int) -> int | None:
    """Locate the anchor word sequence in the transcript, starting at search_from.
    Exact window match first; fuzzy (difflib) fallback for TTS mis-transcriptions."""
    n = len(anchor)
    if n == 0:
        return None
    # exact scan
    for i in range(search_from, len(norm_words) - n + 1):
        if norm_words[i:i + n] == anchor:
            return i
    # fuzzy scan
    best_i, best_r = None, 0.0
    for i in range(search_from, len(norm_words) - n + 1):
        r = difflib.SequenceMatcher(None, norm_words[i:i + n], anchor).ratio()
        if r > best_r:
            best_i, best_r = i, r
    return best_i if best_r >= 0.6 else None

entries, cursor, misses = [], 0, []
for s in scenes:
    anchor = [re.sub(r"[^a-z0-9]", "", w) for w in anchor_words(s["text"])]
    idx = find_anchor(anchor, cursor)
    if idx is None:
        misses.append(s["num"])
        continue
    start = WORDS[idx]["start"]
    img = next(iter(IMAGES.glob(f"{s['num']}x.*")), None)
    clip = next(iter(MOTION.glob(f"{s['num']}*.mp4")), None) if MOTION.is_dir() else None
    entries.append({
        "scene": s["num"],
        "path": str(img.relative_to(BASE)) if img else None,
        "motion": str(clip.relative_to(BASE)) if clip else None,
        "start": round(start, 3),
        "start_frame": round(start * FPS),
    })
    cursor = idx  # scenes are ordered; never search backwards

# durations = gap to the next scene; last scene runs to end of audio
audio_end = WORDS[-1]["end"] if WORDS else 0
for i, e in enumerate(entries):
    nxt = entries[i + 1]["start"] if i + 1 < len(entries) else audio_end + 1.0
    e["duration"] = round(max(nxt - e["start"], 0.5), 3)

out = BASE / "_assembly" / "sync-map.json"
out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps({"fps": FPS, "scenes": entries}, indent=2), encoding="utf-8")

print(f"✓ Sync map: {len(entries)}/{len(scenes)} scenes → {out}")
if misses:
    print(f"⚠ Anchors NOT found for scenes: {misses}")
    print("  Check: did the voiceover text change vs the script table? Fix and rerun.")
    sys.exit(1)
missing_img = [e["scene"] for e in entries if not e["path"]]
if missing_img:
    print(f"⚠ Scenes without an image file: {missing_img}")
    sys.exit(1)
