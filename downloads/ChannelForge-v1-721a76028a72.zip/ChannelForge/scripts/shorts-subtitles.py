#!/usr/bin/env python3
"""
Shorts subtitles: cuts SRT files from the full-video transcript for the
scene ranges chosen in step 5.3. Timecodes are rebased to zero (a short
starts at 0:00).

Usage: python3 scripts/shorts-subtitles.py <video-folder> 12-34 80-100
Requires: timestamps.json + _assembly/sync-map.json
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from video_project import video_dir_from_argv

BASE = video_dir_from_argv()
MAX_WORDS, MAX_GAP = 5, 0.6  # words per caption line / silence that breaks a group


def fmt(sec):
    h, m = int(sec // 3600), int((sec % 3600) // 60)
    s, ms = int(sec % 60), int(round((sec % 1) * 1000))
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


words = json.loads((BASE / "timestamps.json").read_text(encoding="utf-8"))["words"]
sync = json.loads((BASE / "_assembly" / "sync-map.json").read_text(encoding="utf-8"))["scenes"]
start_of = {s["scene"]: s["start"] for s in sync}
dur_of = {s["scene"]: s["duration"] for s in sync}

# group words into caption cues
cues, group = [], []
for w in words:
    if group and (len(group) >= MAX_WORDS or w["start"] - group[-1]["end"] > MAX_GAP):
        cues.append((group[0]["start"], group[-1]["end"], " ".join(g["word"] for g in group)))
        group = []
    group.append(w)
if group:
    cues.append((group[0]["start"], group[-1]["end"], " ".join(g["word"] for g in group)))

ranges = []
for a in sys.argv[2:]:
    lo, hi = a.split("-")
    ranges.append((int(lo), int(hi)))
if not ranges:
    sys.exit("Usage: shorts-subtitles.py <video-folder> 12-34 80-100")

for idx, (lo, hi) in enumerate(ranges, 1):
    k_lo, k_hi, k_next = f"{lo:03d}", f"{hi:03d}", f"{hi+1:03d}"
    if k_lo not in start_of:
        print(f"Short {idx}: scene {lo} not in sync map — skipped")
        continue
    t0 = start_of[k_lo]
    t1 = start_of.get(k_next, start_of.get(k_hi, t0) + dur_of.get(k_hi, 0))
    sel = [(s, e, t) for (s, e, t) in cues if s < t1 and e > t0]
    out = BASE / f"short-{idx}-subs.srt"
    parts = []
    for i, (s, e, t) in enumerate(sel, 1):
        s2 = max(s - t0, 0)
        e2 = max(e - t0, s2 + 0.1)
        parts.append(f"{i}\n{fmt(s2)} --> {fmt(e2)}\n{t}\n")
    out.write_text("\n".join(parts), encoding="utf-8")
    print(f"Short {idx}: scenes {lo}-{hi} → window {t0:.1f}–{t1:.1f}s, {len(sel)} cues → {out.name}")
